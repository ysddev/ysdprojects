<?php
// Обновление каталога по прайсу 23.11.2026: цены (до 130 Ач +30%, свыше +20%), снятые позиции скрыть, новые добавить.
// php apply.php            — только посчитать
// php apply.php --go       — применить (копия каталога в ~/bak)
$dry = !in_array('--go', $argv, true);
$H = getenv('HOME'); $f = $H . '/www/akb-66.ru/catalog.json'; if (!is_file($f)) exit("NO CATALOG\n");
$cat = json_decode(file_get_contents($f), true); $p = json_decode(file_get_contents(__DIR__ . '/patch.json'), true);
$byId = []; foreach ($cat as $i => $x) $byId[$x['id']] = $i;
$nu = 0; $miss = 0; $hid = 0; $was_h = 0; $add = 0; $dup = 0; $up = 0; $down = 0;
foreach ($p['upd'] as $id => $pr) { if (!isset($byId[$id])) { $miss++; continue; } $x = &$cat[$byId[$id]]; if (!empty($x['h'])) $was_h++; if ($x['pr'] != $pr) { $nu++; $pr > $x['pr'] ? $up++ : $down++; } $x['pr'] = $pr; unset($x); }
foreach ($p['hide'] as $id) if (isset($byId[$id]) && empty($cat[$byId[$id]]['h'])) { $cat[$byId[$id]]['h'] = 1; $hid++; }
$max = 0; foreach ($cat as $x) $max = max($max, (int)preg_replace('/\D/', '', $x['id']));
$sig = fn($x) => $x['b'] . '|' . $x['t'] . '|' . $x['c'] . '|' . $x['p'] . '|' . $x['k'] . '|' . ($x['a'] ?? '');
$have = []; foreach ($cat as $x) $have[$sig($x)] = 1;
foreach ($p['add'] as $x) { if (isset($have[$sig($x)])) { $dup++; continue; } $x = ['id' => sprintf('AKB-%04d', ++$max)] + $x; $cat[] = $x; $add++; }
printf("цены: %d из %d (выросли %d, снизились %d), нет на сайте %d, из них были скрыты %d; скрыто снятых %d; добавлено %d (уже были %d); всего %d, видно %d\n",
    $nu, count($p['upd']), $up, $down, $miss, $was_h, $hid, $add, $dup, count($cat), count(array_filter($cat, fn($x) => empty($x['h']) && !empty($x['pr']))));
if ($dry) { echo "DRY\n"; exit; }
copy($f, $H . '/bak/catalog-' . date('mdHi') . '.json');
file_put_contents($f . '.tmp', json_encode(array_values($cat), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX); rename($f . '.tmp', $f);
echo "APPLIED\n";
