<?php
declare(strict_types=1);
require __DIR__ . '/../api/lib.php';
require __DIR__ . '/../api/content.php';
require __DIR__ . '/../api/market.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict', 'secure' => !empty($_SERVER['HTTPS'])]);
session_name('v66adm');
session_start();
header('X-Frame-Options: DENY');
header('Cache-Control: no-store');

const SECTIONS = ['how' => 'Как выбрать', 'request' => 'Заявка на подбор', 'delivery' => 'Доставка и самовывоз', 'faqs' => 'Частые вопросы'];
const SECTION_OF = ['Как выбрать' => 'how', 'Заявка на подбор' => 'request', 'Доставка и самовывоз' => 'delivery', 'Частые вопросы' => 'faqs'];
const TM_LIST = ['Стандартные', 'Конус', 'Конус/болт', 'Болт', 'Винт', 'Тонкие (азиатские)'];
const TE_LIST = ['Ca/Ca', 'EFB', 'AGM'];
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(16)); }
function check_csrf(): void { if (!hash_equals(csrf(), (string)($_POST['csrf'] ?? ''))) { http_response_code(400); exit('Обновите страницу'); } }
function go(string $q): void { header('Location: ?' . $q); exit; }

// ---- вход ----
if (isset($_GET['logout'])) { session_destroy(); go(''); }
if (empty($_SESSION['ok'])) {
    $msg = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        usleep(400000);
        $hash = (string)cfg('admin_hash', '');
        if ($hash !== '' && password_verify((string)($_POST['pass'] ?? ''), $hash)) { session_regenerate_id(true); $_SESSION['ok'] = 1; go('p=orders'); }
        $msg = $hash === '' ? 'Пароль админки не задан в data/config.php' : 'Неверный пароль';
    }
    page('Вход', '<form method="post" class="box narrow"><h1>66 Вольт — админка</h1>' . ($msg ? '<p class="err">' . h($msg) . '</p>' : '') .
        '<label>Пароль<input type="password" name="pass" autofocus required></label><button>Войти</button></form>');
}

$p = $_GET['p'] ?? 'orders';
if ($_SERVER['REQUEST_METHOD'] === 'POST') { check_csrf(); handle_post($p); }

if ($p === 'products') products(); elseif ($p === 'texts') texts_page(); elseif ($p === 'blocks') blocks_page(); elseif ($p === 'brands') brands_page(); elseif ($p === 'cars') cars_page(); elseif ($p === 'diag') diag(); elseif ($p === 'market') market_page(); else orders();

// ---------------- действия ----------------
// Все параметры аккумулятора из формы (общие для «Добавить» и «Изменить»)
function item_from_post(array $x): array {
    $x['b']  = clean($_POST['b'] ?? $x['b'] ?? '', 40) ?: ($x['b'] ?? '');
    $x['t']  = clean($_POST['t'] ?? $x['t'] ?? '', 120) ?: ($x['t'] ?? '');
    $x['c']  = (int)($_POST['c'] ?? $x['c'] ?? 0);
    $x['a']  = ((int)($_POST['a2'] ?? 0)) ?: null;
    $L = (int)($_POST['L'] ?? 0); $W = (int)($_POST['W'] ?? 0); $H = (int)($_POST['H'] ?? 0);
    $x['d']  = ($L && $W && $H) ? [$L, $W, $H] : null;
    $x['p']  = in_array($_POST['pol'] ?? '', ['R', 'L', '3', '4'], true) ? $_POST['pol'] : ($x['p'] ?? '?');
    $x['k']  = in_array($_POST['k'] ?? '', ['E', 'A', 'T'], true) ? $_POST['k'] : ($x['k'] ?? 'E');
    $x['tm'] = in_array($_POST['tm'] ?? '', TM_LIST, true) ? $_POST['tm'] : ($x['tm'] ?? 'Стандартные');
    $x['te'] = in_array($_POST['te'] ?? '', TE_LIST, true) ? $_POST['te'] : 'Ca/Ca';
    $x['lo'] = !empty($_POST['lo']) ? 1 : 0;
    $st = trim((string)($_POST['s'] ?? ''));
    $x['s']  = $st === '' ? null : max(0, (int)$st);
    $x['pr'] = max(0, (int)preg_replace('/\D/', '', (string)($_POST['pr'] ?? ($x['pr'] ?? 0))));
    $x['mf'] = clean($_POST['mf'] ?? ($x['mf'] ?? ''), 80);
    $x['h']  = !empty($_POST['h']) ? 1 : 0;
    if (!empty($_POST['nm'])) $x['nm'] = 1; else unset($x['nm']);
    $gw = (int)preg_replace('/\D/', '', (string)($_POST['gw'] ?? ''));
    if ($gw > 0) $x['gw'] = min($gw, 120); else unset($x['gw']);
    $ds = trim(str_replace("\r", '', strip_tags((string)($_POST['ds'] ?? ''))));
    if ($ds !== '') $x['ds'] = mb_substr($ds, 0, 3000); else unset($x['ds']);
    return $x;
}

function handle_post(string $p): void {
    $a = $_POST['a'] ?? '';
    if ($a === 'status') {
        $allowed = ['new', 'awaiting_payment', 'paid', 'done', 'cancelled', 'request', 'payment_error', 'rejected', 'refunded'];
        $s = $_POST['status'] ?? '';
        if (in_array($s, $allowed, true)) db()->prepare('UPDATE orders SET status=? WHERE id=?')->execute([$s, (int)$_POST['id']]);
        go('p=orders');
    }
    if ($a === 'save' || $a === 'photo' || $a === 'nophoto' || $a === 'add' || $a === 'photo_mk' || $a === 'nophoto_mk') {
        $items = catalog();
        if ($a === 'add') {
            $ids = array_map(fn($x) => (int)substr($x['id'], 4), $items);
            $new = item_from_post(['id' => sprintf('AKB-%04d', max($ids ?: [0]) + 1)]);
            if ($new['b'] && $new['c'] && $new['pr']) { $items[] = $new; save_catalog($items); }
            go('p=products&q=' . urlencode($new['id']));
        }
        $id = (string)($_POST['id'] ?? '');
        foreach ($items as &$x) {
            if ($x['id'] !== $id) continue;
            if ($a === 'save') {
                $x = item_from_post($x);
            } elseif ($a === 'photo' && !empty($_FILES['img']['tmp_name']) && $_FILES['img']['size'] < 6_000_000) {
                $info = @getimagesize($_FILES['img']['tmp_name']);
                $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$info['mime'] ?? ''] ?? null;
                if ($ext) {
                    @mkdir(ROOT . '/uploads', 0755);
                    $fn = 'uploads/' . strtolower($x['id']) . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
                    if (move_uploaded_file($_FILES['img']['tmp_name'], ROOT . '/' . $fn)) {
                        if (!empty($x['img']) && str_starts_with($x['img'], 'uploads/')) @unlink(ROOT . '/' . $x['img']);
                        $x['img'] = $fn;
                    }
                }
            } elseif ($a === 'photo_mk' && !empty($_FILES['img']['tmp_name']) && $_FILES['img']['size'] < 10_000_000) {
                $info = @getimagesize($_FILES['img']['tmp_name']);
                $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$info['mime'] ?? ''] ?? null;
                if ($ext) {
                    @mkdir(ROOT . '/uploads', 0755);
                    $fn = 'uploads/mk-' . strtolower($x['id']) . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
                    if (move_uploaded_file($_FILES['img']['tmp_name'], ROOT . '/' . $fn)) {
                        if (!empty($x['mk']) && str_starts_with($x['mk'], 'uploads/')) @unlink(ROOT . '/' . $x['mk']);
                        $x['mk'] = $fn;
                    }
                }
            } elseif ($a === 'nophoto_mk') {
                if (!empty($x['mk']) && str_starts_with($x['mk'], 'uploads/')) @unlink(ROOT . '/' . $x['mk']);
                unset($x['mk']);
            } elseif ($a === 'nophoto') {
                if (!empty($x['img']) && str_starts_with($x['img'], 'uploads/')) @unlink(ROOT . '/' . $x['img']);
                unset($x['img']);
            }
        }
        unset($x);
        save_catalog($items);
        go((string)($_POST['back'] ?? 'p=products') . '#' . urlencode($id));
    }
    if ($a === 'texts') {
        $c = content(); $d = content_defaults()['texts'] ?? [];
        foreach ($d as $k => $meta) {
            $v = trim(str_replace("\r", '', strip_tags((string)($_POST['t'][$k] ?? ''))));
            if (!empty($meta['line'])) $v = preg_replace('/\s+/u', ' ', $v);
            if ($v === '' || $v === (string)$meta['v']) unset($c['texts'][$k]); else $c['texts'][$k] = mb_substr($v, 0, 2000);
        }
        if (isset($_POST['t']['phone2']) && trim((string)$_POST['t']['phone2']) === '') $c['texts']['phone2'] = ' ';   // пусто = убрать второй телефон
        $c['hide'] = [];
        foreach (SECTIONS as $id => $name) if (empty($_POST['show'][$id])) $c['hide'][$id] = 1;
        save_content($c);
        $_SESSION['flash'] = 'Сохранено. Изменения уже на сайте.';
        go('p=texts');
    }
    if ($a === 'blocks') {
        $c = content();
        $rows = function (string $f1, string $f2, string $k1, string $k2): array {
            $out = [];
            foreach ((array)($_POST[$f1] ?? []) as $i => $v1) {
                if (!empty($_POST['del_' . $f1][$i])) continue;
                $v1 = trim(strip_tags((string)$v1)); $v2 = trim(str_replace("\r", '', strip_tags((string)($_POST[$f2][$i] ?? ''))));
                if ($v1 === '' && $v2 === '') continue;
                $out[] = [$k1 => mb_substr($v1, 0, 300), $k2 => mb_substr($v2, 0, 4000)];
            }
            return $out;
        };
        $c['faq'] = $rows('fq', 'fa', 'q', 'a');
        $c['extra'] = $rows('bt', 'bx', 't', 'x');
        save_content($c);
        $_SESSION['flash'] = 'Сохранено. Изменения уже на сайте.';
        go('p=blocks');
    }
    if ($a === 'brands') {
        $c = content();
        foreach (['brands' => 'br', 'techs' => 'te'] as $key => $f) {
            $c[$key] = [];
            foreach ((array)($_POST[$f] ?? []) as $name => $v) {
                $v = trim(str_replace("\r", '', strip_tags((string)$v)));
                $def = (string)(content_defaults()[$key][$name] ?? '');
                if ($v !== '' && $v !== $def) $c[$key][(string)$name] = mb_substr($v, 0, 3000);
            }
        }
        save_content($c);
        $_SESSION['flash'] = 'Сохранено. Описания видны в карточках товаров.';
        go('p=brands');
    }
    if ($a === 'cars') {
        $cars = car_rows(); $mk = (string)($_POST['mk'] ?? '');
        if (!isset($cars[$mk])) go('p=cars');
        $out = [];
        foreach ((array)($_POST['m'] ?? []) as $i => $m) {
            if (!empty($_POST['del'][$i])) continue;
            $m = clean((string)$m, 80); if ($m === '') continue;
            $gr = array_values(array_intersect(array_keys(CAR_GROUPS), (array)($_POST['gr'][$i] ?? [])));
            if (!$gr) continue;
            $pol = (string)($_POST['pol'][$i] ?? 'R');
            $out[] = ['m' => $m, 'g' => clean((string)($_POST['g'][$i] ?? ''), 80), 'gr' => implode(',', $gr), 'p' => isset(CAR_POL[$pol]) ? $pol : 'R', 'ss' => !empty($_POST['agm'][$i]) ? 2 : (!empty($_POST['ss'][$i]) ? 1 : 0)];
        }
        $new = clean((string)($_POST['rename'] ?? ''), 60);
        if ($new !== '' && $new !== $mk && !isset($cars[$new])) {
            $re = []; foreach ($cars as $k => $v) $re[$k === $mk ? $new : $k] = $k === $mk ? $out : $v; $cars = $re; $mk = $new;
        } else $cars[$mk] = $out;
        save_car_rows($cars);
        $_SESSION['flash'] = 'Сохранено: ' . count($out) . ' строк. Подбор на сайте уже обновлён.';
        go('p=cars&mk=' . urlencode($mk));
    }
    if ($a === 'brand_add') {
        $c = content(); $b = clean((string)($_POST['name'] ?? ''), 40);
        if ($b !== '') { $c['brand_list'] = array_values(array_unique(array_merge((array)($c['brand_list'] ?? []), [$b]))); save_content($c); }
        go('p=products&b=' . urlencode($b) . '#add');
    }
    if ($a === 'car_add') {
        $cars = car_rows(); $mk = clean((string)($_POST['name'] ?? ''), 60);
        if ($mk !== '' && !isset($cars[$mk])) { $cars[$mk] = []; save_car_rows($cars); }
        go('p=cars&mk=' . urlencode($mk));
    }
    if ($a === 'car_del') {
        $cars = car_rows(); $mk = (string)($_POST['mk'] ?? '');
        if (isset($cars[$mk]) && !empty($_POST['sure'])) { unset($cars[$mk]); save_car_rows($cars); $_SESSION['flash'] = 'Марка «' . $mk . '» удалена.'; }
        go('p=cars');
    }
    if ($a === 'mk_brands') {
        $on = array_keys((array)($_POST['br'] ?? [])); $all = array_unique(array_column(pub_items(), 'b'));
        $cc = content(); $cc['mk_off_brands'] = array_values(array_diff($all, $on)); $cc['mk_min_c'] = max(0, (int)($_POST['minc'] ?? 0)); save_content($cc);
        go('p=market');
    }
    if ($a === 'mcard_tpl') {
        $t = (string)($_POST['tpl'] ?? 'a');
        if (in_array($t, ['a', 'b'], true)) { $cc = content(); $cc['mcard_tpl'] = $t; save_content($cc); }
        go('p=market');
    }
    if ($a === 'testmail') {
        $ok = send_mail('Проверка почты — 66 Вольт', 'Если вы видите это письмо, уведомления о заказах будут приходить сюда.');
        $_SESSION['flash'] = $ok ? 'Письмо отправлено на ' . cfg('shop_email') . ' — проверьте почту (и папку «Спам»).' : 'Не удалось отправить письмо: функция mail() на хостинге не сработала.';
        go('p=diag');
    }
    if ($a === 'testmax') {
        $_SESSION['flash'] = send_max('Проверка уведомлений — 66 Вольт') ? 'Сообщение в Max отправлено.' : 'Max не настроен или токен неверный.';
        go('p=diag');
    }
    go('p=' . $p);
}

// ---------------- страницы ----------------
function nav(string $cur): string {
    $l = ['orders' => 'Заказы и заявки', 'products' => 'Товары и цены', 'cars' => 'Подбор по авто', 'texts' => 'Тексты и контакты', 'blocks' => 'Вопросы и блоки', 'brands' => 'Бренды и технологии', 'market' => 'Яндекс Маркет', 'diag' => 'Проверка'];
    $s = '<nav>'; foreach ($l as $k => $t) $s .= '<a href="?p=' . $k . '"' . ($k === $cur ? ' class="on"' : '') . '>' . $t . '</a>';
    return $s . '<a href="../" target="_blank">Сайт ↗</a><a href="?logout=1">Выйти</a></nav>';
}

function orders(): void {
    $rows = db()->query('SELECT * FROM orders ORDER BY id DESC LIMIT 300')->fetchAll();
    $sts = ['new', 'awaiting_payment', 'paid', 'done', 'cancelled', 'payment_error', 'rejected', 'refunded', 'request'];
    $o = nav('orders') . '<div class="box"><h1>Заказы и заявки</h1>';
    if (!$rows) $o .= '<p class="muted">Пока пусто. Новые заказы и заявки появятся здесь и придут на почту.</p>';
    foreach ($rows as $r) {
        $items = json_decode($r['items'], true) ?: [];
        $o .= '<div class="ord st-' . h($r['status']) . '"><div class="oh"><b>' . ($r['kind'] === 'request' ? 'Заявка на подбор' : 'Заказ') . ' №' . (int)$r['id'] . '</b><span>' . h($r['created']) . '</span>';
        $o .= '<form method="post"><input type="hidden" name="csrf" value="' . csrf() . '"><input type="hidden" name="a" value="status"><input type="hidden" name="id" value="' . (int)$r['id'] . '"><select name="status" onchange="this.form.submit()">';
        foreach ($sts as $s) $o .= '<option value="' . $s . '"' . ($s === $r['status'] ? ' selected' : '') . '>' . h(status_name($s)) . '</option>';
        $o .= '</select></form></div>';
        if ($r['kind'] === 'request') {
            $o .= '<p>Авто: <b>' . h($r['note']) . '</b><br>Телефон: <a href="tel:' . h($r['phone']) . '">' . h($r['phone']) . '</a></p>';
        } else {
            $o .= '<ul>'; foreach ($items as $it) $o .= '<li>' . h($it['name']) . ' × ' . (int)$it['q'] . ' — ' . rub((int)$it['sum']) . '</li>'; $o .= '</ul>';
            $o .= '<p><b>Итого: ' . rub((int)$r['total']) . '</b><br>' . h($r['name']) . ', <a href="tel:' . h($r['phone']) . '">' . h($r['phone']) . '</a>' . ($r['email'] ? ', ' . h($r['email']) : '') .
                '<br>' . ($r['dlv'] !== 'pickup' ? ($r['dlv'] === 'courier_obl' ? 'Курьер (область): ' : 'Курьер: ') . h($r['addr']) : 'Самовывоз из магазина') . ' · ' . ($r['pay'] === 'online' ? 'оплата на сайте' : 'оплата при получении') .
                ($r['note'] ? '<br><span class="muted">' . h($r['note']) . '</span>' : '') . '</p>';
        }
        $o .= '</div>';
    }
    page('Заказы', $o . '</div>');
}

function item_fields(array $x): string {
    $sel = function (string $name, array $opts, $cur) { $o = '<select name="' . $name . '">'; foreach ($opts as $v => $t) $o .= '<option value="' . h($v) . '"' . ((string)$v === (string)$cur ? ' selected' : '') . '>' . h($t) . '</option>'; return $o . '</select>'; };
    $d = $x['d'] ?? [null, null, null];
    return '<label>Бренд<input name="b" list="dlb" value="' . h($x['b'] ?? '') . '" required placeholder="выберите или впишите новый"></label>' .
        '<label class="w2">Название / серия<input name="t" value="' . h($x['t'] ?? '') . '" required></label>' .
        '<label>Ёмкость, Ач<input name="c" inputmode="numeric" value="' . h($x['c'] ?? '') . '" required></label>' .
        '<label>Ток, А (EN)<input name="a2" inputmode="numeric" value="' . h($x['a'] ?? '') . '"></label>' .
        '<label>Длина, мм<input name="L" inputmode="numeric" value="' . h($d[0] ?? '') . '"></label>' .
        '<label>Ширина, мм<input name="W" inputmode="numeric" value="' . h($d[1] ?? '') . '"></label>' .
        '<label>Высота, мм<input name="H" inputmode="numeric" value="' . h($d[2] ?? '') . '"></label>' .
        '<label>Полярность' . $sel('pol', ['R' => 'Обратная', 'L' => 'Прямая', '3' => 'Грузовая тип 3', '4' => 'Грузовая тип 4'], $x['p'] ?? 'R') . '</label>' .
        '<label>Корпус' . $sel('k', ['E' => 'Европейский', 'A' => 'Азиатский', 'T' => 'Грузовой'], $x['k'] ?? 'E') . '</label>' .
        '<label>Клеммы' . $sel('tm', array_combine(TM_LIST, TM_LIST), $x['tm'] ?? 'Стандартные') . '</label>' .
        '<label>Технология' . $sel('te', ['Ca/Ca' => 'Ca/Ca (жидкостный)', 'EFB' => 'EFB', 'AGM' => 'AGM'], ($x['te'] ?? 'Ca/Ca') === 'Стандарт' ? 'Ca/Ca' : ($x['te'] ?? 'Ca/Ca')) . '</label>' .
        '<label>Гарантия, мес<input name="gw" inputmode="numeric" value="' . h($x['gw'] ?? '') . '" placeholder="не указана"></label>' .
        '<label>Цена, ₽<input name="pr" inputmode="numeric" value="' . h($x['pr'] ?? '') . '" required></label>' .
        '<label>Остаток, шт<input name="s" inputmode="numeric" value="' . h($x['s'] ?? '') . '" placeholder="не указан"></label>' .
        '<label class="w2">Производитель (завод)<input name="mf" list="dlm" value="' . h($x['mf'] ?? '') . '" placeholder="выберите или впишите новый"></label>' .
        '<label class="full">Описание (видно покупателю в карточке товара)<textarea name="ds" rows="3">' . h($x['ds'] ?? '') . '</textarea></label>' .
        '<label class="ck"><input type="checkbox" name="lo" value="1"' . (!empty($x['lo']) ? ' checked' : '') . '> Низкий корпус</label>' .
        '<label class="ck"><input type="checkbox" name="h" value="1"' . (!empty($x['h']) ? ' checked' : '') . '> Скрыть с сайта</label>' .
        '<label class="ck"><input type="checkbox" name="nm" value="1"' . (!empty($x['nm']) ? ' checked' : '') . '> Не выгружать на Маркет</label>';
}

function products(): void {
    $q = trim((string)($_GET['q'] ?? '')); $ql = mb_strtolower($q);
    $br = trim((string)($_GET['b'] ?? ''));
    $hid = !empty($_GET['hid']);
    $all = catalog();
    $brands = [];
    foreach ($all as $x) $brands[$x['b']] = ($brands[$x['b']] ?? 0) + 1;
    arsort($brands);
    foreach ((array)(content()['brand_list'] ?? []) as $nb) if (!isset($brands[$nb])) $brands[$nb] = 0;
    $mfs = []; foreach ($all as $x) if (!empty($x['mf'])) $mfs[$x['mf']] = 1;
    $list = array_values(array_filter($all, function ($x) use ($ql, $br, $hid) {
        if ($br !== '' && $x['b'] !== $br) return false;
        if ($hid && empty($x['h'])) return false;
        return $ql === '' || str_contains(mb_strtolower($x['id'] . ' ' . $x['b'] . ' ' . $x['t'] . ' ' . ($x['mf'] ?? '') . ' ' . $x['c'] . 'ач'), $ql);
    }));
    $per = 40; $pages = max(1, (int)ceil(count($list) / $per));
    $pg = min($pages, max(1, (int)($_GET['pg'] ?? 1)));
    $show = array_slice($list, ($pg - 1) * $per, $per);
    $base = ['p' => 'products'] + ($q !== '' ? ['q' => $q] : []) + ($br !== '' ? ['b' => $br] : []) + ($hid ? ['hid' => 1] : []);
    $back = http_build_query($base + ($pg > 1 ? ['pg' => $pg] : []));
    $c = csrf();
    $o = nav('products') . '<div class="box"><h1>Товары и цены</h1>';
    $o .= '<div class="chips"><a href="?' . h(http_build_query(['p' => 'products'])) . '"' . ($br === '' && !$hid ? ' class="on"' : '') . '>Все <b>' . count($all) . '</b></a>';
    foreach ($brands as $name => $n) $o .= '<a href="?' . h(http_build_query(['p' => 'products', 'b' => $name])) . '"' . ($br === $name ? ' class="on"' : '') . '>' . h($name) . ' <b>' . $n . '</b></a>';
    $o .= '<a href="?p=products&amp;hid=1"' . ($hid ? ' class="on"' : '') . '>Скрытые</a></div>';
    $o .= '<form method="post" class="row" style="margin:-4px 0 12px"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="brand_add"><label class="w">Новый бренд<input name="name" placeholder="Например: Bosch" required></label><button class="ghost">Добавить бренд</button></form>';
    $o .= '<datalist id="dlb">'; foreach ($brands as $bn => $_) $o .= '<option value="' . h($bn) . '">'; $o .= '</datalist><datalist id="dlm">'; foreach ($mfs as $mn => $_) $o .= '<option value="' . h($mn) . '">'; $o .= '</datalist>';
    $o .= '<form class="search"><input type="hidden" name="p" value="products">' . ($br !== '' ? '<input type="hidden" name="b" value="' . h($br) . '">' : '') .
        '<input name="q" value="' . h($q) . '" placeholder="Поиск' . ($br !== '' ? ' в «' . h($br) . '»' : '') . ': модель, ёмкость, артикул (например «60» или «AKB-0123»)"><button>Найти</button></form>';
    $o .= '<p class="muted">' . ($br !== '' ? 'Бренд «' . h($br) . '»: ' : '') . 'найдено ' . count($list) . ($pages > 1 ? ', страница ' . $pg . ' из ' . $pages : '') . '. Нажмите «Изменить», чтобы править любые параметры. Цена — розничная, в рублях.</p>';
    foreach ($show as $x) {
        $o .= '<div class="prod' . (!empty($x['h']) ? ' off' : '') . '" id="' . h($x['id']) . '"><div class="ph">' . (!empty($x['img']) ? '<img src="../' . h($x['img']) . '" alt="">' : '<span>нет фото</span>') . '</div><div class="pf">';
        $o .= '<div class="t1"><b>' . h($x['t']) . '</b> · ' . (int)$x['c'] . ' Ач' . ($x['a'] ? ' · ' . (int)$x['a'] . ' А' : '') . ' · <b>' . number_format((int)$x['pr'], 0, ',', ' ') . ' ₽</b>' . (!empty($x['h']) ? ' · <span class="red">скрыт</span>' : '') . (!empty($x['nm']) ? ' · <span class="muted">не на Маркете</span>' : '') . '</div>';
        $o .= '<div class="muted">' . h($x['id']) . ' · ' . h($x['b']) . ($x['d'] ? ' · ' . h(implode('×', $x['d'])) . ' мм' : '') . ' · ' . (['R' => 'обратная', 'L' => 'прямая', '3' => 'тип 3', '4' => 'тип 4'][$x['p']] ?? 'полярность не указана') . '</div>';
        $o .= '<details class="ed"><summary>Изменить</summary><form method="post" class="grid"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="save"><input type="hidden" name="id" value="' . h($x['id']) . '"><input type="hidden" name="back" value="' . h($back) . '">' . item_fields($x) . '<button>Сохранить</button></form>';
        $o .= '<div class="row"><form method="post" enctype="multipart/form-data" class="row"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="photo"><input type="hidden" name="id" value="' . h($x['id']) . '"><input type="hidden" name="back" value="' . h($back) . '"><input type="file" name="img" accept="image/jpeg,image/png,image/webp" required><button class="ghost">Загрузить фото</button></form>';
        if (!empty($x['img'])) $o .= '<form method="post"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="nophoto"><input type="hidden" name="id" value="' . h($x['id']) . '"><input type="hidden" name="back" value="' . h($back) . '"><button class="ghost">Удалить фото</button></form>';
        $o .= '</div><div class="row"><span class="muted">Доп. фото для Маркета' . (!empty($x['mk']) ? ' (загружено: <a href="../' . h($x['mk']) . '" target="_blank">смотреть</a>)' : '') . ':</span><form method="post" enctype="multipart/form-data" class="row"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="photo_mk"><input type="hidden" name="id" value="' . h($x['id']) . '"><input type="hidden" name="back" value="' . h($back) . '"><input type="file" name="img" accept="image/jpeg,image/png,image/webp" required><button class="ghost">Загрузить</button></form>';
        if (!empty($x['mk'])) $o .= '<form method="post"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="nophoto_mk"><input type="hidden" name="id" value="' . h($x['id']) . '"><input type="hidden" name="back" value="' . h($back) . '"><button class="ghost">Удалить</button></form>';
        $o .= '</div></details></div></div>';
    }
    if ($pages > 1) {
        $o .= '<div class="chips pages">';
        for ($i = 1; $i <= $pages; $i++) $o .= '<a href="?' . h(http_build_query($base + ['pg' => $i])) . '"' . ($i === $pg ? ' class="on"' : '') . '>' . $i . '</a>';
        $o .= '</div>';
    }
    $o .= '<details class="add" id="add"' . ($br !== '' && ($brands[$br] ?? 0) === 0 ? ' open' : '') . '><summary>Добавить новый аккумулятор' . ($br !== '' ? ' бренда «' . h($br) . '»' : '') . '</summary><form method="post" class="grid"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="add">' .
        item_fields($br !== '' ? ['b' => $br] : []) . '<button>Добавить</button></form></details>';
    page('Товары', $o . '</div>');
}


function flash(): string { $f = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']); return $f ? '<p class="ok">' . h($f) . '</p>' : ''; }

function texts_page(): void {
    $d = content_defaults()['texts'] ?? []; $c = content(); $hide = (array)($c['hide'] ?? []);
    $groups = [];
    foreach ($d as $k => $meta) $groups[$meta['g']][$k] = $meta;
    $o = nav('texts') . '<div class="box"><h1>Тексты и контакты</h1>' . flash() .
        '<p class="muted">Меняйте любой текст и нажмите «Сохранить» внизу. Пустое поле — вернётся текст по умолчанию. Перенос строки в тексте сохраняется. Телефоны, почта и адрес меняются сразу везде: на сайте и в документах.</p>' .
        '<form method="post"><input type="hidden" name="csrf" value="' . csrf() . '"><input type="hidden" name="a" value="texts">';
    foreach ($groups as $g => $items) {
        $o .= '<fieldset><legend>' . h($g) . '</legend>';
        if (isset(SECTION_OF[$g])) { $id = SECTION_OF[$g]; $o .= '<label class="ck sw"><input type="checkbox" name="show[' . $id . ']" value="1"' . (empty($hide[$id]) ? ' checked' : '') . '> Показывать этот блок на сайте</label>'; }
        foreach ($items as $k => $meta) {
            $cur = $c['texts'][$k] ?? '';
            $val = trim((string)$cur) !== '' ? trim((string)$cur) : (string)$meta['v'];
            if ($k === 'phone2' && $cur === ' ') $val = '';
            $o .= '<label>' . h($meta['l']) . (!empty($meta['line']) || mb_strlen($val) < 60
                ? '<input name="t[' . h($k) . ']" value="' . h($val) . '">'
                : '<textarea name="t[' . h($k) . ']" rows="' . max(2, min(6, (int)ceil(mb_strlen($val) / 90))) . '">' . h($val) . '</textarea>') . '</label>';
        }
        $o .= '</fieldset>';
    }
    $o .= '<div class="stick"><button>Сохранить</button></div></form></div>';
    page('Тексты', $o);
}

function blocks_page(): void {
    $faq = ct_list('faq'); $ex = ct_list('extra'); $c = csrf();
    $o = nav('blocks') . '<div class="box"><h1>Вопросы и блоки</h1>' . flash() . '<form method="post"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="blocks">';
    $o .= '<fieldset><legend>Частые вопросы</legend><p class="muted">Чтобы добавить вопрос — заполните пустую строку внизу. Чтобы убрать — отметьте «Удалить».</p>';
    $faq[] = ['q' => '', 'a' => '']; $faq[] = ['q' => '', 'a' => ''];
    foreach ($faq as $i => $qa) $o .= '<div class="rowbox"><label>Вопрос<input name="fq[' . $i . ']" value="' . h($qa['q'] ?? '') . '"></label><label>Ответ<textarea name="fa[' . $i . ']" rows="3">' . h($qa['a'] ?? '') . '</textarea></label>' . (($qa['q'] ?? '') !== '' ? '<label class="ck"><input type="checkbox" name="del_fq[' . $i . ']" value="1"> Удалить</label>' : '') . '</div>';
    $o .= '</fieldset><fieldset><legend>Дополнительные блоки</legend><p class="muted">Свои блоки с заголовком и текстом — например, акция, «Сдайте старый аккумулятор» или «О магазине». Появляются на сайте перед частыми вопросами.</p>';
    $ex[] = ['t' => '', 'x' => '']; $ex[] = ['t' => '', 'x' => ''];
    foreach ($ex as $i => $b) $o .= '<div class="rowbox"><label>Заголовок<input name="bt[' . $i . ']" value="' . h($b['t'] ?? '') . '"></label><label>Текст<textarea name="bx[' . $i . ']" rows="4">' . h($b['x'] ?? '') . '</textarea></label>' . (($b['t'] ?? '') !== '' || ($b['x'] ?? '') !== '' ? '<label class="ck"><input type="checkbox" name="del_bt[' . $i . ']" value="1"> Удалить блок</label>' : '') . '</div>';
    $o .= '</fieldset><div class="stick"><button>Сохранить</button></div></form></div>';
    page('Вопросы и блоки', $o);
}

function brands_page(): void {
    $brands = []; foreach (catalog() as $x) $brands[$x['b']] = ($brands[$x['b']] ?? 0) + 1; arsort($brands);
    foreach ((array)(content()['brand_list'] ?? []) as $nb) if (!isset($brands[$nb])) $brands[$nb] = 0;
    $bm = ct_map('brands'); $tm = ct_map('techs');
    $o = nav('brands') . '<div class="box"><h1>Бренды и технологии</h1>' . flash() . '<p class="muted">Эти описания покупатель видит в карточке аккумулятора (нажать на товар в каталоге). Пустое поле — описание не показывается.</p><form method="post"><input type="hidden" name="csrf" value="' . csrf() . '"><input type="hidden" name="a" value="brands">';
    $o .= '<fieldset><legend>Технологии</legend>';
    foreach (TE_LIST as $t) $o .= '<label>' . h($t === 'Ca/Ca' ? 'Ca/Ca (жидкостный)' : $t) . '<textarea name="te[' . h($t) . ']" rows="2">' . h($tm[$t] ?? '') . '</textarea></label>';
    $o .= '</fieldset><fieldset><legend>Бренды</legend>';
    foreach ($brands as $b => $n) $o .= '<label>' . h($b) . ' <span class="muted">· ' . $n . ' товаров</span><textarea name="br[' . h($b) . ']" rows="2" placeholder="Например: где производится, чем хорош, гарантия">' . h($bm[$b] ?? '') . '</textarea></label>';
    $o .= '</fieldset><div class="stick"><button>Сохранить</button></div></form></div>';
    page('Бренды', $o);
}

function cars_page(): void {
    $cars = car_rows(); $mk = (string)($_GET['mk'] ?? ''); $c = csrf();
    $o = nav('cars') . '<div class="box"><h1>Подбор по авто</h1>' . flash();
    $o .= '<div class="chips">'; foreach ($cars as $k => $rows) $o .= '<a href="?' . h(http_build_query(['p' => 'cars', 'mk' => $k])) . '"' . ($k === $mk ? ' class="on"' : '') . '>' . h($k) . ' <b>' . count($rows) . '</b></a>';
    $o .= '</div><form method="post" class="row"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="car_add"><label class="w">Новая марка<input name="name" placeholder="Например: Chery" required></label><button class="ghost">Добавить марку</button></form>';
    $o .= '<details class="legend"><summary>Что такое типоразмеры (L2, B24…)?</summary><table><tr><td><b>Типоразмер</b></td><td><b>Д×Ш×В, мм</b></td><td><b>Ёмкость, Ач</b></td></tr>';
    foreach (CAR_GROUPS as $g => $v) $o .= '<tr><td>' . h(CAR_GNAME[$g]) . '</td><td>' . $v[0] . '×' . $v[1] . '×' . $v[2] . '</td><td>' . $v[3] . '–' . $v[4] . '</td></tr>';
    $o .= '</table><p class="muted">Сайт сам находит в каталоге аккумуляторы, которые подходят по размеру, ёмкости и полярности. Если у машины подходят несколько типоразмеров — отметьте все.</p></details>';
    if ($mk === '' || !isset($cars[$mk])) { page('Подбор по авто', $o . '<p class="muted">Выберите марку выше.</p></div>'); return; }
    $rows = $cars[$mk]; for ($i = 0; $i < 5; $i++) $rows[] = ['m' => '', 'g' => '', 'gr' => '', 'p' => 'R', 'ss' => 0];
    $o .= '<form method="post"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="cars"><input type="hidden" name="mk" value="' . h($mk) . '">';
    $o .= '<div class="row"><label class="w">Марка<input name="rename" value="' . h($mk) . '"></label></div><p class="muted">Каждая строка — модель (и при необходимости поколение / годы). <b>Несколько поколений</b> — нажмите «+ поколение» у модели: появится ещё строка с той же моделью, впишите годы и отметьте размеры. Пустые строки внизу — для новых моделей. «Старт-стоп» — подойдут EFB и AGM, «Только AGM» — только AGM.</p>';
    foreach ($rows as $i => $r) {
        $sel = array_flip(array_filter(explode(',', (string)$r['gr'])));
        $o .= '<div class="carrow"><div class="cr1"><label>Модель<input name="m[' . $i . ']" value="' . h($r['m']) . '"></label><label>Поколение / годы<input name="g[' . $i . ']" value="' . h($r['g']) . '" placeholder="можно пусто"></label>' .
            '<label>Полярность<select name="pol[' . $i . ']">'; foreach (CAR_POL as $pv => $pn) $o .= '<option value="' . h($pv) . '"' . ($pv === (string)$r['p'] ? ' selected' : '') . '>' . h($pn) . '</option>';
        $o .= '</select></label><label class="ck"><input type="checkbox" name="ss[' . $i . ']" value="1"' . (!empty($r['ss']) ? ' checked' : '') . '> Старт-стоп</label><label class="ck"><input type="checkbox" name="agm[' . $i . ']" value="1"' . ((int)$r['ss'] === 2 ? ' checked' : '') . '> Только AGM</label>' . ($r['m'] !== '' ? '<label class="ck"><input type="checkbox" name="del[' . $i . ']" value="1"> Удалить</label>' : '') . '</div><div class="grs">';
        foreach (CAR_GROUPS as $g => $v) $o .= '<label class="gb"><input type="checkbox" name="gr[' . $i . '][]" value="' . $g . '"' . (isset($sel[$g]) ? ' checked' : '') . '>' . h(CAR_GNAME[$g]) . '</label>';
        $o .= '</div>' . ($r['m'] !== '' ? '<button type="button" class="ghost addgen">+ поколение</button>' : '') . '</div>';
    }
    $o .= '<script>let gi=' . (count($rows) + 1000) . ';document.addEventListener("click",e=>{const b=e.target.closest(".addgen");if(!b)return;const row=b.closest(".carrow");const n=row.cloneNode(true);const i=gi++;n.querySelectorAll("[name]").forEach(el=>{el.name=el.name.replace(/\\[\\d+\\]/,"["+i+"]");});const g=n.querySelector("input[name^=\\"g[\\"]");if(g){g.value="";}n.querySelectorAll("input[name^=\\"del[\\"]").forEach(el=>el.closest("label").remove());row.after(n);if(g)g.focus();});</script>';
    $o .= '<div class="stick"><button>Сохранить марку «' . h($mk) . '»</button></div></form>';
    $o .= '<form method="post" class="row" style="margin-top:24px"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="car_del"><input type="hidden" name="mk" value="' . h($mk) . '"><label class="ck"><input type="checkbox" name="sure" value="1" required> Да, удалить марку целиком</label><button class="ghost">Удалить марку</button></form>';
    page('Подбор по авто', $o . '</div>');
}

function market_page(): void {
    $all = pub_items(); $in = mk_items(); $no = array_values(array_filter($all, fn($x) => empty($x['img'])));
    $url = site_url() . '/market.yml'; $tpl = mc_tpl();
    $o = nav('market') . '<div class="box"><h1>Яндекс Маркет</h1>';
    $o .= '<p>Ссылка на выгрузку (вставляется в кабинете Маркета: Товары → Загрузить и обновить → Ссылка на yml-файл):</p><p><input readonly value="' . h($url) . '" onclick="this.select()" style="width:100%"></p>';
    $o .= '<p>Маркет сам забирает выгрузку примерно раз в 30 минут: новые цены, товары и фото из админки попадают туда без вашего участия.</p>';
    $o .= '<p><b>В выгрузке: ' . count($in) . ' товаров.</b> Без фото и потому не выгружаются: ' . count($no) . ' (видимые на сайте). Скрытые товары, товары без цены, с остатком 0 и отключённые для Маркета в выгрузку не попадают.</p>';
    $o .= '<p class="muted">У каждого товара в выгрузке до трёх фото: 1) ваше основное фото, 2) карточка с характеристиками (собирается автоматически), 3) доп. фото для Маркета — его можно загрузить в «Товары и цены» → «Изменить».</p>';
    $o .= '<h2>Оформление карточек</h2><form method="post" class="mcv"><input type="hidden" name="csrf" value="' . csrf() . '"><input type="hidden" name="a" value="mcard_tpl">';
    $ex = $in[0] ?? null;
    foreach (['a' => 'Тёмная', 'b' => 'Светлая'] as $k => $n) {
        $src = '';
        if ($ex) { $pf = ROOT . '/uploads/mcard/preview-' . $k . '-' . mc_hash($ex, $k) . '.jpg'; if (!is_file($pf)) { @mkdir(dirname($pf), 0755, true); foreach (glob(ROOT . '/uploads/mcard/preview-' . $k . '-*.jpg') ?: [] as $old) @unlink($old); $im = mc_render($ex, $k, ROOT . '/' . $ex['img']); imagejpeg($im, $pf, 85); imagedestroy($im); } $src = '../uploads/mcard/' . basename($pf); }
        $o .= '<label class="mcv-i"><input type="radio" name="tpl" value="' . $k . '"' . ($tpl === $k ? ' checked' : '') . '> ' . $n . ($src ? '<img src="' . h($src) . '" alt="">' : '') . '</label>';
    }
    $o .= '<button>Сохранить оформление</button></form>';
    if (!$ex) $o .= '<p class="muted">Пример появится, когда у товаров будут фото.</p>';
    $off = mk_off_brands(); $bc = []; foreach ($all as $x) $bc[$x['b']] = ($bc[$x['b']] ?? 0) + 1; ksort($bc);
    $o .= '<h2>Что выгружать на Маркет</h2><p class="muted">Снимите галочку у брендов, которых нет в наличии, — они останутся на сайте, но не попадут на Маркет. Отдельный товар можно убрать с Маркета в «Товары и цены» → «Изменить» → «Не выгружать на Маркет». Товары с остатком 0 на Маркет не выгружаются сами.</p>';
    $o .= '<form method="post" class="chips"><input type="hidden" name="csrf" value="' . csrf() . '"><input type="hidden" name="a" value="mk_brands">';
    foreach ($bc as $b => $n) $o .= '<label class="ck"><input type="checkbox" name="br[' . h($b) . ']" value="1"' . (in_array($b, $off, true) ? '' : ' checked') . '> ' . h($b) . ' <span class="muted">' . $n . '</span></label>';
    $o .= '<label style="flex-basis:100%">Выгружать на Маркет только от <input name="minc" type="number" min="0" step="1" value="' . (mk_min_c() ?: '') . '" placeholder="0" style="width:90px;display:inline-block"> Ач (пусто — все ёмкости)</label>';
    $o .= '<button>Сохранить</button></form>';
    if ($no) {
        $o .= '<h2>Нет фото (' . count($no) . ')</h2><p class="muted">Загрузите фото — товар сам попадёт в выгрузку.</p><div class="chips">';
        foreach (array_slice($no, 0, 300) as $x) $o .= '<a href="?p=products&q=' . urlencode($x['id']) . '">' . h($x['b'] . ' ' . short_title($x) . ' ' . (int)$x['c'] . ' Ач') . '</a>';
        $o .= '</div>';
    }
    page('Яндекс Маркет', $o . '</div>');
}

function diag(): void {
    $flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
    $c = csrf();
    $chk = [];
    $chk[] = ['PHP', PHP_VERSION, version_compare(PHP_VERSION, '8.0', '>=')];
    $chk[] = ['Папка data доступна для записи', is_writable(DATA) ? 'да' : 'нет', is_writable(DATA)];
    $chk[] = ['Каталог', count(catalog()) . ' товаров', count(catalog()) > 0];
    $chk[] = ['Почта для заказов', (string)cfg('shop_email'), (bool)cfg('shop_email')];
    $term = (string)cfg('tbank_terminal');
    $chk[] = ['Терминал Т-Банка', $term ? (str_ends_with($term, 'DEMO') ? 'ТЕСТОВЫЙ (оплаты не настоящие)' : 'рабочий') : 'не задан', (bool)$term];
    // связь с API банка (без создания платежа)
    $ch = curl_init(rtrim((string)cfg('tbank_api'), '/') . '/GetState');
    $opt = [CURLOPT_POST => true, CURLOPT_POSTFIELDS => '{}', CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15];
    if (cfg('tbank_cainfo')) $opt[CURLOPT_CAINFO] = cfg('tbank_cainfo');
    curl_setopt_array($ch, $opt); $r = curl_exec($ch); $err = curl_error($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $chk[] = ['Связь с API Т-Банка (TLS)', $r === false ? 'ошибка: ' . $err : "есть (HTTP $code)", $r !== false];
    $chk[] = ['Max', cfg('max_token') ? 'настроен' : 'не настроен — уведомления только на почту', (bool)cfg('max_token')];
    $o = nav('diag') . '<div class="box"><h1>Проверка</h1>' . ($flash ? '<p class="ok">' . h($flash) . '</p>' : '') . '<table>';
    foreach ($chk as [$n, $v, $ok]) $o .= '<tr><td>' . h($n) . '</td><td class="' . ($ok ? 'g' : 'r') . '">' . h($v) . '</td></tr>';
    $o .= '</table><div class="row"><form method="post"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="testmail"><button>Отправить тестовое письмо</button></form>' .
        '<form method="post"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="testmax"><button class="ghost">Проверить Max</button></form></div></div>';
    page('Проверка', $o);
}

function page(string $title, string $body, bool $exit = true): void {
    echo '<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . h($title) . ' — 66 Вольт</title><style>
*{box-sizing:border-box}body{margin:0;font:15px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#F4F5F7;color:#1B1D22}
nav{display:flex;flex-wrap:wrap;gap:4px;padding:10px 16px;background:#16181D}nav a{color:#C3C7CF;text-decoration:none;padding:10px 12px;border-radius:9px}nav a.on{background:#F5A524;color:#16181D;font-weight:600}
.box{max-width:1000px;margin:16px auto;background:#fff;border-radius:16px;padding:20px}.narrow{max-width:360px;margin-top:12vh}h1{font-size:22px;margin:0 0 14px}
label{display:flex;flex-direction:column;gap:4px;font-size:13px;color:#545A66}input,select{font:inherit;padding:10px 12px;border:1.5px solid #E3E5EA;border-radius:10px;min-height:44px;color:#1B1D22;background:#fff}
button{font:inherit;font-weight:600;min-height:44px;padding:0 16px;border:0;border-radius:10px;background:#F5A524;color:#16181D;cursor:pointer}button.ghost{background:#F4F5F7}
.err{color:#C0392B}.ok{background:#E3F4EA;color:#1E6B3E;padding:10px 12px;border-radius:10px}.muted{color:#7A808A;font-size:13.5px}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end;margin-top:8px}.row label.w{flex:1;min-width:200px}.row label.ck{flex-direction:row;align-items:center;min-height:44px}
.search{display:flex;gap:8px;margin-bottom:8px}.search input{flex:1}
.mcv{display:flex;flex-wrap:wrap;gap:16px;align-items:flex-end}.mcv-i{display:flex;flex-direction:column;gap:8px;font-weight:600;cursor:pointer}.mcv-i input{width:auto;min-height:0;align-self:flex-start}.mcv-i img{width:240px;border-radius:12px;border:1px solid #E3E5EA}
.prod{display:flex;gap:14px;padding:14px 0;border-top:1px solid #E3E5EA}.ph{flex:0 0 96px;height:96px;border-radius:12px;background:#F4F5F7;display:grid;place-items:center;overflow:hidden;font-size:12px;color:#9AA0AA}.ph img{width:100%;height:100%;object-fit:contain}.pf{flex:1;min-width:0}
.ord{border:1.5px solid #E3E5EA;border-radius:14px;padding:12px 14px;margin-bottom:10px}.oh{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.oh span{color:#7A808A;font-size:13px}.oh form{margin-left:auto}
.ord.st-new,.ord.st-request{border-color:#F5A524}.ord.st-paid{border-color:#1E8E4E}.ord.st-payment_error,.ord.st-rejected{border-color:#D93A2B}ul{margin:8px 0;padding-left:18px}
table{width:100%;border-collapse:collapse}td{padding:10px 6px;border-bottom:1px solid #E3E5EA}td.g{color:#1E8E4E}td.r{color:#C0392B}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 12px}.chips a{padding:8px 12px;border-radius:999px;background:#F4F5F7;color:#16181D;text-decoration:none;font-size:14px}.chips a b{color:#6B7280;font-weight:600}.chips a.on{background:#F5A524}.chips a.on b{color:#16181D}.pages{margin-top:14px}.t1{margin-bottom:2px}.red{color:#C2410C;font-weight:600}.prod.off{opacity:.6}.ed summary{cursor:pointer;color:#B45309;font-weight:600;padding:6px 0}.ed .grid{margin:6px 0 10px}.grid .w2{grid-column:span 2}.grid label.ck{display:flex;flex-direction:row;align-items:center;justify-content:flex-start;gap:8px;min-height:44px}.grid label.ck input{width:auto;min-height:0}.add{margin-top:16px}.add summary{cursor:pointer;font-weight:600;padding:10px 0}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;align-items:end}
fieldset{border:1.5px solid #E3E5EA;border-radius:14px;padding:12px 14px 14px;margin:0 0 16px;display:grid;gap:10px}legend{font-weight:700;padding:0 6px}textarea{font:inherit;padding:10px 12px;border:1.5px solid #E3E5EA;border-radius:10px;resize:vertical;color:#1B1D22}label.ck{flex-direction:row;align-items:center;gap:8px}label.ck input{min-height:0}.sw{font-weight:600;color:#1B1D22}.stick{position:sticky;bottom:0;background:#fff;padding:12px 0;border-top:1px solid #E3E5EA}.rowbox{display:grid;gap:8px;padding:10px 0;border-top:1px dashed #E3E5EA}.grid .full{grid-column:1/-1}.carrow{border-top:1px solid #E3E5EA;padding:10px 0}.cr1{display:grid;grid-template-columns:1.3fr 1fr 1fr auto auto;gap:8px;align-items:end}.grs{display:flex;flex-wrap:wrap;gap:4px;margin-top:8px}.gb{flex-direction:row;align-items:center;gap:5px;padding:6px 9px;border:1.5px solid #E3E5EA;border-radius:999px;font-size:13px;color:#1B1D22;cursor:pointer}.gb input{min-height:0;margin:0}.gb:has(input:checked){background:#FFF3DC;border-color:#F5A524}.legend summary{cursor:pointer;color:#B45309;font-weight:600;padding:8px 0}.legend td{padding:6px}
@media(max-width:700px){.cr1{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.prod{flex-direction:column}.ph{width:96px}}
</style></head><body>' . $body . '</body></html>';
    if ($exit) exit;
}
