<?php
require __DIR__ . '/api/market.php';
header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: no-cache');
header('Access-Control-Allow-Origin: https://partner.market.yandex.ru');
echo mk_yml();
