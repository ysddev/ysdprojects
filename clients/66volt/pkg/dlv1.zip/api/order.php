<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'POST only'], 405);
$in = read_json();
if (!empty($in['hp'])) json_out(['ok' => true, 'order' => 0]); // ловушка для ботов
rate_limit(10, 3600);

$name  = clean($in['name'] ?? '', 80);
$phone = norm_phone((string)($in['phone'] ?? ''));
$email = clean($in['email'] ?? '', 120);
// Решение клиента 18.11.2026: курьер или самовывоз из магазина (Арамиль), оплата только на сайте (чеки — облачная касса Т-Банка)
$dlv   = in_array($in['dlv'] ?? '', ['pickup', 'courier', 'courier_obl'], true) ? (string)$in['dlv'] : 'courier';
$addr  = clean($in['addr'] ?? '', 250);
$pay   = 'online';

$err = [];
if ($name === '') $err[] = 'Укажите имя';
if (!$phone) $err[] = 'Проверьте номер телефона';
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $err[] = 'Проверьте почту';
if ($dlv !== 'pickup' && $addr === '') $err[] = 'Укажите адрес доставки';
if (empty($in['agree'])) $err[] = 'Нужно согласие с офертой';

$cat = catalog_by_id();
$items = []; $total = 0;
foreach (array_slice((array)($in['items'] ?? []), 0, 30) as $it) {
    $id = (string)($it['id'] ?? ''); $q = (int)($it['q'] ?? 0);
    if (!isset($cat[$id]) || !empty($cat[$id]['h']) || $q < 1 || $q > 20) continue;
    $x = $cat[$id]; $price = (int)$x['pr'];
    $nm = trim($x['b'] . ' ' . $x['c'] . ' Ач, ' . $x['t']);
    $items[] = ['id' => $id, 'name' => mb_substr($nm, 0, 120), 'q' => $q, 'price' => $price, 'sum' => $price * $q];
    $total += $price * $q;
}
// доставка — отдельной строкой заказа и чека
if ($items && $dlv !== 'pickup') {
    require_once __DIR__ . '/content.php';
    $dc = dlv_cost($dlv, $total); $zn = dlv_zones()[$dlv][0];
    $items[] = ['id' => 'DLV', 'name' => mb_substr('Доставка ' . ($dlv === 'courier' ? $zn : '(' . $zn . ')'), 0, 120), 'q' => 1, 'price' => $dc, 'sum' => $dc];
    $total += $dc;
}
if (!$items) $err[] = 'Корзина пуста или товары больше не продаются — обновите страницу';
if ($err) json_out(['ok' => false, 'error' => implode('. ', $err)], 422);

$db = db();
$st = $db->prepare('INSERT INTO orders(created,kind,name,phone,email,dlv,addr,pay,items,total,status,ip) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');
$st->execute([date('Y-m-d H:i:s'), 'order', $name, $phone, $email, $dlv, $addr, $pay,
    json_encode($items, JSON_UNESCAPED_UNICODE), $total, $pay === 'online' ? 'awaiting_payment' : 'new', client_ip()]);
$id = (int)$db->lastInsertId();
$o = $db->query("SELECT * FROM orders WHERE id=$id")->fetch();

if ($pay !== 'online') {
    notify("Новый заказ №$id — " . rub($total), order_text($o));
    json_out(['ok' => true, 'order' => $id]);
}

// --- оплата через Т-Банк ---
if (!cfg('tbank_terminal') || !cfg('tbank_password')) {
    $db->prepare("UPDATE orders SET status='payment_error', note=? WHERE id=?")->execute(['Т-Банк не настроен', $id]);
    notify("Заказ №$id — оплата не настроена", order_text($o) . "\nОнлайн-оплата ещё не подключена — свяжитесь с покупателем.");
    json_out(['ok' => true, 'order' => $id, 'notice' => 'Онлайн-оплата скоро заработает. Мы свяжемся с вами для подтверждения заказа.']);
}

$site = rtrim((string)cfg('site_url'), '/');
$receiptItems = array_map(fn($it) => [
    'Name' => mb_substr($it['name'], 0, 128), 'Price' => $it['price'] * 100, 'Quantity' => $it['q'],
    'Amount' => $it['sum'] * 100, 'Tax' => cfg('vat', 'none'), 'PaymentMethod' => 'full_payment', 'PaymentObject' => $it['id'] === 'DLV' ? 'service' : 'commodity',
], array_values(array_filter($items, fn($it) => $it['sum'] > 0)));
$receipt = ['Taxation' => cfg('taxation', 'usn_income_outcome'), 'Items' => $receiptItems];
if ($email !== '') $receipt['Email'] = $email; else $receipt['Phone'] = $phone;

$res = tbank_call('Init', [
    'Amount' => $total * 100,
    'OrderId' => '66V-' . $id,
    'Description' => "Заказ №$id в магазине 66 Вольт",
    'NotificationURL' => "$site/api/notify.php",
    'SuccessURL' => "$site/pay-success.html?order=$id",
    'FailURL' => "$site/pay-fail.html?order=$id",
    'DATA' => array_filter(['Phone' => $phone, 'Email' => $email]),
    'Receipt' => $receipt,
]);

if (!empty($res['Success']) && !empty($res['PaymentURL'])) {
    $db->prepare('UPDATE orders SET payment_id=? WHERE id=?')->execute([(string)($res['PaymentId'] ?? ''), $id]);
    notify("Заказ №$id — ждёт оплаты " . rub($total), order_text($o) . "\nПокупатель перешёл к оплате картой.");
    json_out(['ok' => true, 'order' => $id, 'paymentUrl' => $res['PaymentURL']]);
}

$why = trim(($res['Message'] ?? '') . ' ' . ($res['Details'] ?? ''));
$db->prepare("UPDATE orders SET status='payment_error', note=? WHERE id=?")->execute([mb_substr($why, 0, 500), $id]);
notify("Заказ №$id — ошибка оплаты", order_text($o) . "\nБанк ответил: $why\nСвяжитесь с покупателем.");
json_out(['ok' => true, 'order' => $id, 'notice' => 'Не получилось открыть оплату. Заказ сохранён — мы позвоним и поможем оплатить.']);
