<?php
declare(strict_types=1);

const ROOT = __DIR__ . '/..';
// Данные (настройки, база заказов, логи) — вне папки сайта, если есть ../akb66-data; иначе data/ (закрыта .htaccess)
define('DATA', is_dir(ROOT . '/../akb66-data') ? realpath(ROOT . '/../akb66-data') : ROOT . '/data');

function cfg(string $k, $def = null) {
    static $c = null;
    if ($c === null) {
        $f = DATA . '/config.php';
        $c = is_file($f) ? (require $f) : [];
    }
    return $c[$k] ?? $def;
}

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $pdo = new PDO('sqlite:' . DATA . '/shop.sqlite');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA journal_mode=WAL');
    $pdo->exec("CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT, kind TEXT, name TEXT, phone TEXT, email TEXT,
        dlv TEXT, addr TEXT, pay TEXT, items TEXT, total INTEGER, status TEXT, payment_id TEXT, note TEXT, ip TEXT)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS hits(ip TEXT, ts INTEGER)");
    return $pdo;
}

function json_out(array $a, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($a, JSON_UNESCAPED_UNICODE);
    exit;
}

function read_json(): array {
    $raw = file_get_contents('php://input') ?: '';
    if (strlen($raw) > 20000) json_out(['ok' => false, 'error' => 'Слишком большой запрос'], 413);
    $d = json_decode($raw, true);
    return is_array($d) ? $d : [];
}

function client_ip(): string { return $_SERVER['REMOTE_ADDR'] ?? ''; }

// Не больше $max запросов с одного IP за $win секунд
function rate_limit(int $max = 8, int $win = 3600): void {
    $ip = client_ip(); $now = time();
    $db = db();
    $db->prepare('DELETE FROM hits WHERE ts < ?')->execute([$now - $win]);
    $st = $db->prepare('SELECT COUNT(*) FROM hits WHERE ip = ?'); $st->execute([$ip]);
    if ((int)$st->fetchColumn() >= $max) json_out(['ok' => false, 'error' => 'Слишком много заявок подряд. Позвоните нам, пожалуйста.'], 429);
    $db->prepare('INSERT INTO hits(ip, ts) VALUES(?, ?)')->execute([$ip, $now]);
}

function clean(?string $s, int $max = 200): string {
    $s = trim(preg_replace('/\s+/u', ' ', (string)$s));
    return mb_substr(strip_tags($s), 0, $max);
}

function norm_phone(string $p): ?string {
    $d = preg_replace('/\D/', '', $p);
    if (strlen($d) === 11 && ($d[0] === '8' || $d[0] === '7')) $d = '7' . substr($d, 1);
    elseif (strlen($d) === 10) $d = '7' . $d;
    return (strlen($d) === 11 && $d[0] === '7') ? '+' . $d : null;
}

function catalog(): array {
    static $c = null;
    if ($c === null) {
        $c = json_decode((string)@file_get_contents(ROOT . '/catalog.json'), true) ?: [];
    }
    return $c;
}

function catalog_by_id(): array {
    $m = [];
    foreach (catalog() as $x) $m[$x['id']] = $x;
    return $m;
}

function save_catalog(array $items): void {
    $tmp = ROOT . '/catalog.json.tmp';
    file_put_contents($tmp, json_encode(array_values($items), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    rename($tmp, ROOT . '/catalog.json');
}

function rub(int $n): string { return number_format($n, 0, ',', ' ') . ' ₽'; }

// ---------- уведомления ----------
function send_mail(string $subject, string $body): bool {
    $to = cfg('shop_email'); if (!$to) return false;
    $from = cfg('from_email', 'noreply@akb-66.ru');
    $headers = "From: 66 Вольт <$from>\r\nContent-Type: text/plain; charset=UTF-8\r\nMIME-Version: 1.0";
    return @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers);
}

function max_api(string $method, string $path, array $query = [], ?array $body = null): ?array {
    $tok = cfg('max_token'); if (!$tok) return null;
    $url = 'https://platform-api.max.ru' . $path . ($query ? '?' . http_build_query($query) : '');
    $ch = curl_init($url);
    $opt = [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10,
        CURLOPT_HTTPHEADER => ['Authorization: ' . $tok, 'Content-Type: application/json']];
    if ($body !== null) $opt[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_UNICODE);
    curl_setopt_array($ch, $opt);
    $r = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($r === false) return null;
    $j = json_decode($r, true); if (!is_array($j)) $j = [];
    $j['_http'] = $code;
    return $j;
}

// Уведомление в Max: бот магазина пишет в чат с владелицей (max_chat_id)
function send_max(string $text): bool {
    $chats = array_filter(array_map('trim', explode(',', (string)cfg('max_chat_id'))));
    if (!$chats || !cfg('max_token')) return false;
    $ok = false;
    foreach ($chats as $chat) {   // можно несколько чатов через запятую
        $r = max_api('POST', '/messages', ['chat_id' => $chat], ['text' => mb_substr($text, 0, 3900)]);
        if ($r !== null && $r['_http'] < 300) $ok = true;
    }
    return $ok;
}

function notify(string $subject, string $body): void {
    send_mail($subject, $body);
    send_max($subject . "\n\n" . $body);
    @file_put_contents(DATA . '/notify.log', date('c') . " | $subject\n", FILE_APPEND | LOCK_EX);
}

function order_text(array $o): string {
    $items = json_decode($o['items'] ?? '[]', true) ?: [];
    $t = "Заказ №{$o['id']}\n";
    foreach ($items as $it) $t .= "• {$it['name']} × {$it['q']} = " . rub($it['sum']) . "\n";
    $t .= "Итого: " . rub((int)$o['total']) . "\n\n";
    $t .= "Имя: {$o['name']}\nТелефон: {$o['phone']}\n";
    if ($o['email']) $t .= "Почта: {$o['email']}\n";
    $t .= 'Получение: ' . ($o['dlv'] === 'pickup' ? 'самовывоз из магазина (г. Арамиль, ул. 1 Мая, 13)' : ($o['dlv'] === 'courier_obl' ? 'курьер по области' : 'курьер по Екатеринбургу') . ", адрес: {$o['addr']}") . "\n";
    $t .= 'Оплата: ' . ($o['pay'] === 'online' ? 'картой на сайте' : 'при получении') . "\n";
    $t .= 'Статус: ' . status_name($o['status']) . "\n";
    return $t;
}

function status_name(string $s): string {
    return ['new' => 'новый', 'awaiting_payment' => 'ждёт оплаты', 'paid' => 'оплачен', 'payment_error' => 'ошибка оплаты',
            'rejected' => 'оплата отклонена', 'done' => 'выдан', 'cancelled' => 'отменён', 'request' => 'заявка на подбор',
            'refunded' => 'возврат'][$s] ?? $s;
}

// ---------- Т-Банк ----------
function tbank_token(array $params): string {
    $p = [];
    foreach ($params as $k => $v) {
        if ($k === 'Token' || is_array($v) || is_object($v)) continue;   // вложенные объекты (Receipt, DATA) не участвуют
        if (is_bool($v)) $v = $v ? 'true' : 'false';
        $p[$k] = (string)$v;
    }
    $p['Password'] = (string)cfg('tbank_password', '');
    ksort($p, SORT_STRING);
    return hash('sha256', implode('', $p));
}

function tbank_call(string $method, array $params): array {
    $params['TerminalKey'] = cfg('tbank_terminal');
    $params['Token'] = tbank_token($params);
    $ch = curl_init(rtrim((string)cfg('tbank_api'), '/') . '/' . $method);
    $opt = [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode($params, JSON_UNESCAPED_UNICODE)];
    if (cfg('tbank_cainfo')) $opt[CURLOPT_CAINFO] = cfg('tbank_cainfo');
    curl_setopt_array($ch, $opt);
    $r = curl_exec($ch); $err = curl_error($ch); curl_close($ch);
    if ($r === false) return ['Success' => false, 'Message' => 'Нет связи с банком', 'Details' => $err];
    return json_decode($r, true) ?: ['Success' => false, 'Message' => 'Непонятный ответ банка', 'Details' => mb_substr($r, 0, 300)];
}
