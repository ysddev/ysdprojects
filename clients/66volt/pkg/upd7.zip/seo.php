<?php
require __DIR__ . '/api/seo.php';
$r = (string)($_GET['r'] ?? '');
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
if ($r !== 'sitemap' && !str_ends_with($path, '/')) { header('Location: ' . $path . '/', true, 301); exit; }   // один адрес — со слешем
$sl = fn($k) => preg_match('/^[a-z0-9-]{1,120}$/', (string)($_GET[$k] ?? '')) ? (string)$_GET[$k] : '';
switch ($r) {
    case 'akb': page_catalog(); break;
    case 'item': page_akb($sl('s')); break;
    case 'auto': page_auto(); break;
    case 'make': page_make($sl('mk')); break;
    case 'model': page_model($sl('mk'), $sl('md')); break;
    case 'sitemap': page_sitemap(); break;
    default: not_found();
}
