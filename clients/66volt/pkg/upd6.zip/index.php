<?php
require __DIR__ . '/api/seo.php';
serve_page(__DIR__ . '/page.tpl.html');
