<?php
declare(strict_types=1);
// Страницы для поисковиков: товары (/akb/…), каталог (/akb/), подбор по авто (/auto/…), карта сайта.
// Всё строится из catalog.json и cars.json — новые товары и модели из админки получают страницы сами.
require_once __DIR__ . '/content.php';

function site_url(): string { return rtrim((string)cfg('site_url', 'https://akb-66.ru'), '/'); }

// ---- товары ----
function te_name(string $te): string { return $te === 'Стандарт' || $te === 'Ca/Ca' ? 'Ca/Ca' : $te; }
function short_title(array $x): string {
    $r = (string)$x['t']; $b = (string)$x['b'];
    if (mb_stripos($r, $b) === 0) $r = trim(mb_substr($r, mb_strlen($b)));
    $r = preg_replace('/^(Профессионал|\(Эльф\))\s*/u', '', $r);
    return $r !== '' ? mb_strtoupper(mb_substr($r, 0, 1)) . mb_substr($r, 1) : '';
}
function item_name(array $x): string { $s = short_title($x); return trim($x['b'] . ' ' . $s) . ', ' . (int)$x['c'] . ' Ач'; }
function item_num(array $x): string { return preg_replace('/\D/', '', (string)$x['id']); }
function item_slug(array $x): string { return trim(translit($x['b'] . ' ' . short_title($x) . ' ' . (int)$x['c'] . 'ah'), '-') . '-' . item_num($x); }
function item_url(array $x): string { return '/akb/' . item_slug($x) . '/'; }
function pub_items(): array {
    static $l = null;
    if ($l === null) { $l = []; foreach (catalog() as $x) if (empty($x['h']) && !empty($x['pr'])) { $x['te'] = te_name((string)($x['te'] ?? 'Ca/Ca')); $l[] = $x; } }
    return $l;
}
const POL_NAME = ['R' => 'обратная полярность', 'L' => 'прямая полярность', '3' => 'тип 3 (обратная)', '4' => 'тип 4 (прямая)'];
const POL_SHORT = ['R' => 'Обратная (+ справа)', 'L' => 'Прямая (+ слева)', '3' => 'Тип 3 (обратная)', '4' => 'Тип 4 (прямая)'];
const BODY_NAME = ['E' => 'Европейский', 'A' => 'Азиатский', 'T' => 'Грузовой'];

// ---- подбор по авто (та же логика, что на сайте) ----
function car_fits(array $x, array $gr, string $pol, int $ss): bool {
    $pols = $pol === 'RL' ? ['R', 'L'] : ($pol === '34' ? ['3', '4'] : [$pol]);
    if (!in_array((string)$x['p'], $pols, true)) return false;
    if ($ss && !in_array($x['te'], $ss === 2 ? ['AGM'] : ['EFB', 'AGM'], true)) return false;
    foreach ($gr as $g) {
        $G = CAR_GROUPS[$g] ?? null; if (!$G) continue;
        if ($x['c'] < $G[3] - 2 || $x['c'] > $G[4] + 5) continue;
        if ($g[0] === 'T') return true;
        $low = str_ends_with($g, 'L');
        if (!empty($x['d'])) { $d = $x['d']; if ($d[0] <= $G[0] + 5 && $d[0] >= $G[0] - 20 && abs($d[1] - $G[1]) <= 10 && $d[2] <= $G[2] + ($low ? 4 : 8)) return true; continue; }
        if ($x['k'] === ($g[0] === 'A' ? 'A' : 'E') && (!$low || !empty($x['lo']))) return true;
    }
    return false;
}
// Марки → модели → строки (поколения), со ссылками
function car_tree(): array {
    static $t = null; if ($t !== null) return $t;
    $t = []; $mkSlugs = [];
    foreach (car_rows() as $mk => $rows) {
        $ms = translit($mk) ?: 'marka'; while (isset($mkSlugs[$ms])) $ms .= '-2'; $mkSlugs[$ms] = 1;
        $models = []; $mdSlugs = [];
        foreach ($rows as $r) {
            $m = trim((string)($r['m'] ?? '')); if ($m === '' || trim((string)($r['gr'] ?? '')) === '') continue;
            if (!isset($models[$m])) { $sl = translit($m) ?: 'model'; while (isset($mdSlugs[$sl])) $sl .= '-2'; $mdSlugs[$sl] = 1; $models[$m] = ['name' => $m, 'slug' => $sl, 'rows' => []]; }
            $models[$m]['rows'][] = ['g' => trim((string)($r['g'] ?? '')), 'gr' => array_values(array_filter(explode(',', (string)$r['gr']))), 'p' => (string)$r['p'], 'ss' => (int)$r['ss']];
        }
        if ($models) $t[$ms] = ['name' => $mk, 'slug' => $ms, 'models' => array_values($models)];
    }
    return $t;
}
function fits_row(array $row): array {
    $out = []; foreach (pub_items() as $x) if (car_fits($x, $row['gr'], $row['p'], $row['ss'])) $out[] = $x;
    usort($out, fn($a, $b) => ((int)($b['s'] ?? 0) > 0) <=> ((int)($a['s'] ?? 0) > 0) ?: $a['pr'] <=> $b['pr']);
    return $out;
}
// Для карточки товара: какие машины подходят
function cars_for(array $x): array {
    $out = [];
    foreach (car_tree() as $mk) foreach ($mk['models'] as $md) foreach ($md['rows'] as $r) {
        if (car_fits($x, $r['gr'], $r['p'], $r['ss'])) { $out[$mk['slug'] . '/' . $md['slug']] = ['name' => $mk['name'] . ' ' . $md['name'], 'url' => '/auto/' . $mk['slug'] . '/' . $md['slug'] . '/']; break; }
    }
    return array_values($out);
}

// ---- оболочка страницы: стили, шапка и подвал главной ----
function shell_parts(): array {
    static $p = null; if ($p !== null) return $p;
    $h = render_page(ROOT . '/page.tpl.html');
    preg_match('#<head>.*?<link rel="icon"[^>]*>(.*?)</head>#s', $h, $m1);
    $head = $m1[1] ?? '';
    $head = preg_replace('#<script[\s\S]*?</script>#', '', $head);           // скрипты главной не нужны
    preg_match('#<header class="hd">[\s\S]*?</header>#', $h, $m2);
    preg_match('#<footer>[\s\S]*?</footer>#', $h, $m3);
    $hdr = $m2[0] ?? ''; $ftr = $m3[0] ?? '';
    $hdr = str_replace(['href="#top"', 'href="#catalog"', 'href="#delivery"', 'href="#how"', 'href="#request"', 'href="#picker"'], ['href="/"', 'href="/akb/"', 'href="/#delivery"', 'href="/#how"', 'href="/#request"', 'href="/auto/"'], $hdr);
    $hdr = preg_replace('#<button class="cartbtn" id="cartOpen"([^>]*)>([\s\S]*?)</button>#', '<a class="cartbtn" href="/?cart=1"$1>$2</a>', $hdr);
    $ftr = preg_replace('#href="(oferta|privacy|delivery)\.php"#', 'href="/$1.php"', $ftr);
    $metr = render_metrika();
    return $p = ['head' => $head, 'hdr' => $hdr, 'ftr' => $ftr, 'metrika' => $metr];
}
function render_metrika(): string {
    $mid = preg_replace('/\D/', '', ct('metrika'));
    return $mid ? '<script>(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})(window,document,"script","https://mc.yandex.ru/metrika/tag.js","ym");ym(' . $mid . ',"init",{clickmap:true,trackLinks:true,accurateTrackBounce:true,webvisor:true});</script>' : '';
}
function h2(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function seo_page(string $title, string $desc, string $canon, string $body, array $crumbs = [], array $ld = []): void {
    $P = shell_parts(); $url = site_url() . $canon;
    $bc = ''; $bl = [];
    if ($crumbs) {
        $bc = '<nav class="bc" aria-label="Навигация"><a href="/">Главная</a>';
        $i = 1; $bl[] = ['@type' => 'ListItem', 'position' => $i++, 'name' => 'Главная', 'item' => site_url() . '/'];
        foreach ($crumbs as $c) {
            $bc .= ' <span>›</span> ' . (isset($c[1]) ? '<a href="' . h2($c[1]) . '">' . h2($c[0]) . '</a>' : '<span>' . h2($c[0]) . '</span>');
            $bl[] = ['@type' => 'ListItem', 'position' => $i++, 'name' => $c[0], 'item' => site_url() . ($c[1] ?? $canon)];
        }
        $bc .= '</nav>';
        $ld[] = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $bl];
    }
    $ldh = ''; foreach ($ld as $j) $ldh .= '<script type="application/ld+json">' . json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>';
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-cache');
    echo '<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
        '<title>', h2($title), '</title><meta name="description" content="', h2($desc), '"><link rel="canonical" href="', h2($url), '">',
        '<meta property="og:title" content="', h2($title), '"><meta property="og:description" content="', h2($desc), '"><meta property="og:url" content="', h2($url), '"><meta property="og:type" content="website">',
        '<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 64 64\'%3E%3Crect width=\'64\' height=\'64\' rx=\'14\' fill=\'%2316181D\'/%3E%3Cpath d=\'M36 6 16 36h13l-4 22 23-32H34z\' fill=\'%23F5A524\'/%3E%3C/svg%3E">',
        $P['head'], '<style>', SEO_CSS, '</style>', $ldh, $P['metrika'], '</head><body>', $P['hdr'],
        '<main class="seo"><div class="wrap">', $bc, $body, '</div></main>', $P['ftr'], '<script>', SEO_JS, '</script></body></html>';
}

const SEO_CSS = 'main.seo{padding:88px 0 56px}.bc{font-size:14px;color:var(--m);margin:0 0 14px;display:flex;flex-wrap:wrap;gap:6px}.bc a{color:var(--m)}.seo h1{font-family:Unbounded,sans-serif;font-size:clamp(24px,3.4vw,38px);line-height:1.15;margin:0 0 14px;overflow-wrap:anywhere}.seo p{white-space:normal}.gen:first-of-type{margin-top:8px}.seo h2{font-family:Unbounded,sans-serif;font-size:22px;margin:28px 0 12px}.seo .lead2{color:var(--m);max-width:760px;margin:0 0 18px}
.ip{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.15fr);gap:28px;align-items:start}.ipic{background:var(--l);border-radius:16px;aspect-ratio:4/3;display:grid;place-items:center;overflow:hidden;position:relative}.ipic img{position:absolute;inset:12px;width:calc(100% - 24px);height:calc(100% - 24px);object-fit:contain;mix-blend-mode:multiply}
.spec{width:100%;border-collapse:collapse;font-size:15px}.spec td{padding:9px 0;border-bottom:1px solid var(--line);vertical-align:top}.spec td:first-child{color:var(--m);width:44%;padding-right:12px}
.ibuy{display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin:18px 0}.ibuy .price{font-size:28px}.stock{font-size:14px;color:var(--ok);font-weight:600}
.links{display:flex;flex-wrap:wrap;gap:8px}.links a{padding:8px 12px;border-radius:999px;background:var(--l);color:var(--t);text-decoration:none;font-size:14px}.links a b{color:var(--m);font-weight:600}
.lgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px}.li{display:flex;flex-direction:column;gap:6px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:14px}.li a.nm{color:var(--t);font-weight:600;text-decoration:none}.li .mt{font-size:13px;color:var(--m)}.li .rw{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:auto}.li .pr{font-family:Unbounded,sans-serif;font-weight:700}
.gen{margin:22px 0}.gen:first-of-type{margin-top:8px}.gen h3{font-size:18px;margin:0 0 6px}.note{font-size:14px;color:var(--m);margin:0 0 10px}.info p{max-width:760px}
.brand-list h2{font-size:18px;margin:22px 0 8px}.cols{columns:3 260px;column-gap:24px}.cols a{display:block;break-inside:avoid;padding:4px 0;color:var(--t)}
@media(max-width:760px){.ip{grid-template-columns:1fr}main.seo{padding-top:80px}}';

const SEO_JS = "(function(){var K='v66cart',c={};try{c=JSON.parse(localStorage.getItem(K)||'{}')||{}}catch(e){}function sv(){try{localStorage.setItem(K,JSON.stringify(c))}catch(e){}}function upd(){var n=0;for(var k in c)n+=c[k];var e=document.getElementById('cartCnt');if(e){e.textContent=n;e.classList.toggle('on',n>0)}document.querySelectorAll('[data-add]').forEach(function(b){if(c[b.dataset.add]){b.classList.add('in');b.textContent='В корзине → оформить'}})}document.addEventListener('click',function(e){var b=e.target.closest('[data-add]');if(!b)return;var id=b.dataset.add;if(c[id]){location.href='/?cart=1';return}c[id]=1;sv();upd()});upd()})();";

// ---- страницы ----
function add_btn(array $x): string { return '<button type="button" class="add" data-add="' . h2($x['id']) . '">В корзину</button>'; }
function item_li(array $x): string {
    return '<div class="li"><a class="nm" href="' . item_url($x) . '">' . h2(item_name($x)) . '</a><div class="mt">' . h2(POL_SHORT[$x['p']] ?? '') . ($x['a'] ? ' · ' . (int)$x['a'] . ' А' : '') . ' · ' . h2($x['te']) . (!empty($x['d']) ? ' · ' . implode('×', $x['d']) . ' мм' : '') . '</div><div class="rw"><span class="pr">' . rub((int)$x['pr']) . '</span>' . add_btn($x) . '</div></div>';
}
function bat_svg(string $p): string {
    $tr = in_array($p, ['3', '4'], true);
    return '<svg width="200" height="150" viewBox="0 0 200 150" aria-hidden="true"><rect x="20" y="40" width="160" height="96" rx="10" fill="#16181D"/><rect x="' . ($p === 'L' || $p === '4' ? 36 : 134) . '" y="26" width="30" height="16" rx="3" fill="#D93A2B"/><rect x="' . ($p === 'L' || $p === '4' ? 134 : 36) . '" y="26" width="30" height="16" rx="3" fill="#555B66"/><path d="M104 62 88 92h12l-4 22 18-32h-12z" fill="#F5A524"/></svg>';
}

function page_item(string $slug): void {
    if (!preg_match('/-(\d{1,6})$/', $slug, $m)) { not_found(); return; }
    $x = null; foreach (pub_items() as $it) if (item_num($it) === $m[1]) { $x = $it; break; }
    if (!$x) { not_found(); return; }
    if (item_slug($x) !== $slug) { header('Location: ' . item_url($x), true, 301); return; }
    $name = item_name($x); $pol = POL_NAME[$x['p']] ?? '';
    $title = 'Аккумулятор ' . $name . ', ' . $pol . ' — купить в Екатеринбурге | 66 Вольт';
    $desc = 'Аккумулятор ' . $name . ': ' . ($x['a'] ? 'пусковой ток ' . (int)$x['a'] . ' А, ' : '') . $pol . (!empty($x['d']) ? ', ' . implode('×', $x['d']) . ' мм' : '') . ', ' . $x['te'] . '. Цена ' . rub((int)$x['pr']) . '. Оплата на сайте, доставка по Екатеринбургу, самовывоз в Арамиле.';
    $cars = cars_for($x);
    $rows = [['Производитель', (string)($x['mf'] ?: $x['b'])], ['Бренд', $x['b']], ['Ёмкость', (int)$x['c'] . ' Ач']];
    if ($x['a']) $rows[] = ['Пусковой ток (EN)', (int)$x['a'] . ' А'];
    $rows[] = ['Полярность', POL_SHORT[$x['p']] ?? ''];
    if (!empty($x['d'])) $rows[] = ['Габариты Д×Ш×В', implode(' × ', $x['d']) . ' мм'];
    $rows[] = ['Тип корпуса', (BODY_NAME[$x['k']] ?? '') . (!empty($x['lo']) ? ', низкий' : '')];
    $rows[] = ['Клеммы', (string)$x['tm']];
    $rows[] = ['Технология', $x['te'] === 'Ca/Ca' ? 'Ca/Ca (жидкостный)' : $x['te']];
    if (!empty($x['gw'])) $rows[] = ['Гарантия', (int)$x['gw'] . ' мес.'];
    $tb = ''; foreach ($rows as $r) $tb .= '<tr><td>' . h2($r[0]) . '</td><td>' . h2($r[1]) . '</td></tr>';
    $pic = !empty($x['img']) ? '<img src="/' . h2($x['img']) . '" alt="Аккумулятор ' . h2($name) . '">' : bat_svg((string)$x['p']);
    $o = '<div class="ip"><div class="ipic">' . $pic . '</div><div><h1>Аккумулятор ' . h2($name) . '</h1>' .
        '<div class="ibuy"><span class="price">' . rub((int)$x['pr']) . '</span>' . add_btn($x) . (((int)($x['s'] ?? 0)) > 0 ? '<span class="stock">В наличии</span>' : '') . '</div>' .
        '<table class="spec">' . $tb . '</table><p class="note" style="margin-top:14px">Оплата на сайте картой или СБП, чек придёт на почту. Доставка по Екатеринбургу бесплатно, самовывоз — ' . h2(ct('address')) . '. Телефон: <a href="tel:' . tel_href(ct('phone')) . '">' . h2(ct('phone')) . '</a>.</p></div></div>';
    $info = '';
    if (!empty($x['ds'])) $info .= '<p>' . esc_t((string)$x['ds']) . '</p>';
    $bd = ct_map('brands')[$x['b']] ?? ''; if ($bd) $info .= '<h2>О бренде ' . h2($x['b']) . '</h2><p>' . esc_t($bd) . '</p>';
    $td = ct_map('techs')[$x['te']] ?? ''; if ($td) $info .= '<h2>' . ($x['te'] === 'Ca/Ca' ? 'Технология Ca/Ca (жидкостный)' : 'Технология ' . h2($x['te'])) . '</h2><p>' . esc_t($td) . '</p>';
    if ($info) $o .= '<div class="info">' . $info . '</div>';
    if ($cars) {
        $o .= '<h2>Подходит для автомобилей</h2><div class="links">';
        foreach ($cars as $c) $o .= '<a href="' . h2($c['url']) . '">' . h2($c['name']) . '</a>';
        $o .= '</div><p class="note" style="margin-top:8px">Подбор по размеру, ёмкости и полярности. Перед покупкой сверьте полярность со своим аккумулятором.</p>';
    }
    $sim = array_values(array_filter(pub_items(), fn($y) => $y['id'] !== $x['id'] && $y['p'] === $x['p'] && abs($y['c'] - $x['c']) <= 5 && $y['k'] === $x['k']));
    usort($sim, fn($a, $b) => abs($a['pr'] - $x['pr']) <=> abs($b['pr'] - $x['pr']));
    if ($sim) { $o .= '<h2>Похожие аккумуляторы</h2><div class="lgrid">'; foreach (array_slice($sim, 0, 6) as $y) $o .= item_li($y); $o .= '</div>'; }
    $ld = ['@context' => 'https://schema.org', '@type' => 'Product', 'name' => 'Аккумулятор ' . $name, 'sku' => $x['id'], 'brand' => ['@type' => 'Brand', 'name' => $x['b']], 'description' => $desc,
        'offers' => ['@type' => 'Offer', 'price' => (int)$x['pr'], 'priceCurrency' => 'RUB', 'availability' => 'https://schema.org/' . (((int)($x['s'] ?? 0)) > 0 ? 'InStock' : 'PreOrder'), 'url' => site_url() . item_url($x)]];
    if (!empty($x['img'])) $ld['image'] = site_url() . '/' . $x['img'];
    seo_page($title, $desc, item_url($x), $o, [['Аккумуляторы', '/akb/'], [$x['b'], '/akb/#' . translit($x['b'])], ['Аккумулятор ' . $name]], [$ld]);
}

function page_catalog(): void {
    $by = []; foreach (pub_items() as $x) $by[$x['b']][] = $x;
    uksort($by, fn($a, $b) => count($by[$b]) <=> count($by[$a]) ?: strcmp($a, $b));
    $o = '<h1>Аккумуляторы для автомобилей</h1><p class="lead2">' . count(pub_items()) . ' аккумуляторов ' . count($by) . ' брендов с ценами. Оплата на сайте, доставка по Екатеринбургу и самовывоз в Арамиле. <a href="/#catalog">Открыть каталог с фильтрами</a> или <a href="/auto/">подобрать по марке авто</a>.</p>';
    $o .= '<div class="links">'; foreach ($by as $b => $l) $o .= '<a href="#' . translit($b) . '">' . h2($b) . ' <b>' . count($l) . '</b></a>'; $o .= '</div><div class="brand-list">';
    foreach ($by as $b => $l) {
        usort($l, fn($a, $c) => $a['c'] <=> $c['c'] ?: $a['pr'] <=> $c['pr']);
        $o .= '<h2 id="' . translit($b) . '">' . h2($b) . '</h2><div class="cols">';
        foreach ($l as $x) $o .= '<a href="' . item_url($x) . '">' . h2(item_name($x)) . ' — ' . rub((int)$x['pr']) . '</a>';
        $o .= '</div>';
    }
    $o .= '</div>';
    seo_page('Аккумуляторы для автомобилей — цены, купить в Екатеринбурге | 66 Вольт', 'Каталог автомобильных аккумуляторов: ' . implode(', ', array_slice(array_keys($by), 0, 8)) . ' и другие. Цены, характеристики, подбор по авто. Доставка по Екатеринбургу.', '/akb/', $o, [['Аккумуляторы']]);
}

function page_auto(): void {
    $o = '<h1>Подбор аккумулятора по марке автомобиля</h1><p class="lead2">Выберите марку и модель — покажем аккумуляторы, которые подходят по размеру, ёмкости и полярности.</p><div class="links">';
    foreach (car_tree() as $mk) $o .= '<a href="/auto/' . $mk['slug'] . '/">' . h2($mk['name']) . ' <b>' . count($mk['models']) . '</b></a>';
    $o .= '</div>';
    seo_page('Подбор аккумулятора по марке авто — 66 Вольт, Екатеринбург', 'Подберите аккумулятор для своей машины: LADA, Kia, Hyundai, Renault, Volkswagen и другие марки. Цены, наличие, доставка по Екатеринбургу.', '/auto/', $o, [['Подбор по авто']]);
}

function page_make(string $ms): void {
    $t = car_tree(); $mk = $t[$ms] ?? null; if (!$mk) { not_found(); return; }
    $o = '<h1>Аккумулятор для ' . h2($mk['name']) . '</h1><p class="lead2">Выберите модель ' . h2($mk['name']) . ' — покажем подходящие аккумуляторы с ценами.</p><div class="links">';
    foreach ($mk['models'] as $md) { $n = 0; foreach ($md['rows'] as $r) $n = max($n, count(fits_row($r))); $o .= '<a href="/auto/' . $mk['slug'] . '/' . $md['slug'] . '/">' . h2($mk['name'] . ' ' . $md['name']) . ' <b>' . $n . '</b></a>'; }
    $o .= '</div>';
    seo_page('Аккумулятор для ' . $mk['name'] . ' — подбор по модели, цены | 66 Вольт', 'Аккумуляторы для ' . $mk['name'] . ': подбор по модели и году выпуска, цены, доставка по Екатеринбургу и самовывоз в Арамиле.', '/auto/' . $mk['slug'] . '/', $o, [['Подбор по авто', '/auto/'], [$mk['name']]]);
}

function page_model(string $ms, string $mds): void {
    $t = car_tree(); $mk = $t[$ms] ?? null; $md = null;
    if ($mk) foreach ($mk['models'] as $m) if ($m['slug'] === $mds) { $md = $m; break; }
    if (!$md) { not_found(); return; }
    $full = $mk['name'] . ' ' . $md['name'];
    $o = '<h1>Аккумулятор для ' . h2($full) . '</h1>{{lead}}';
    $minp = null; $cnt = 0; $uids = [];
    foreach ($md['rows'] as $r) {
        $l = fits_row($r); foreach ($l as $x) $uids[$x['id']] = 1; $cnt = count($uids); foreach ($l as $x) $minp = $minp === null ? $x['pr'] : min($minp, $x['pr']);
        $sizes = implode(' / ', array_map(fn($g) => CAR_GNAME[$g] ?? $g, $r['gr']));
        $pl = ['R' => 'обратная (+ справа)', 'L' => 'прямая (+ слева)', 'RL' => 'бывает разной — сверьте со своим АКБ', '3' => 'тип 3', '4' => 'тип 4', '34' => 'тип 3 или 4'][$r['p']] ?? '';
        $o .= '<div class="gen">' . (count($md['rows']) > 1 || $r['g'] !== '' ? '<h3>' . h2($full . ($r['g'] !== '' ? ' ' . $r['g'] : '')) . '</h3>' : '') .
            '<p class="note">Типоразмер ' . h2($sizes) . ', полярность ' . h2($pl) . ($r['ss'] === 2 ? ', нужен AGM' : ($r['ss'] ? ', старт-стоп — нужен EFB или AGM' : '')) . '. Подходит: ' . count($l) . '.</p>';
        if ($l) { $o .= '<div class="lgrid">'; foreach ($l as $x) $o .= item_li($x); $o .= '</div>'; }
        else $o .= '<p>Сейчас в каталоге нет подходящих — <a href="/#request">оставьте заявку</a>, подберём под заказ.</p>';
        $o .= '</div>';
    }
    $o = str_replace('{{lead}}', '<p class="lead2">Подобрали ' . $cnt . ' ' . ($cnt % 10 === 1 && $cnt % 100 !== 11 ? 'аккумулятор' : (in_array($cnt % 10, [2, 3, 4]) && !in_array($cnt % 100, [12, 13, 14]) ? 'аккумулятора' : 'аккумуляторов')) . ' для ' . h2($full) . ($minp ? ' — цены от ' . rub((int)$minp) : '') . '. Оплата на сайте, бесплатная доставка по Екатеринбургу, самовывоз в Арамиле.</p>', $o);
    $o .= '<p class="note">Не уверены? <a href="/#request">Оставьте заявку</a> или позвоните <a href="tel:' . tel_href(ct('phone')) . '">' . h2(ct('phone')) . '</a> — подберём по VIN или году выпуска.</p>';
    $desc = 'Аккумулятор для ' . $full . ': ' . $cnt . ' подходящих вариантов' . ($minp ? ' от ' . rub((int)$minp) : '') . '. Подбор по размеру и полярности, оплата на сайте, доставка по Екатеринбургу.';
    seo_page('Аккумулятор для ' . $full . ' — купить, цены от ' . ($minp ? rub((int)$minp) : '') . ' | 66 Вольт', $desc, '/auto/' . $mk['slug'] . '/' . $md['slug'] . '/', $o, [['Подбор по авто', '/auto/'], [$mk['name'], '/auto/' . $mk['slug'] . '/'], [$md['name']]]);
}

function page_sitemap(): void {
    header('Content-Type: application/xml; charset=utf-8');
    $u = site_url(); $today = date('Y-m-d');
    $urls = ['/' => '1.0', '/akb/' => '0.9', '/auto/' => '0.9'];
    foreach (car_tree() as $mk) { $urls['/auto/' . $mk['slug'] . '/'] = '0.7'; foreach ($mk['models'] as $md) $urls['/auto/' . $mk['slug'] . '/' . $md['slug'] . '/'] = '0.8'; }
    foreach (pub_items() as $x) $urls[item_url($x)] = '0.6';
    foreach (['oferta', 'privacy', 'delivery'] as $d) $urls['/' . $d . '.php'] = '0.2';
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    foreach ($urls as $p => $pr) echo '<url><loc>' . h2($u . $p) . '</loc><lastmod>' . $today . '</lastmod><priority>' . $pr . '</priority></url>';
    echo '</urlset>';
}

function not_found(): void {
    http_response_code(404);
    seo_page('Страница не найдена — 66 Вольт', 'Страница не найдена.', '/404/', '<h1>Страница не найдена</h1><p class="lead2">Возможно, товар уже снят с продажи. <a href="/akb/">Все аккумуляторы</a> · <a href="/auto/">Подбор по авто</a> · <a href="/">Главная</a></p>');
}
