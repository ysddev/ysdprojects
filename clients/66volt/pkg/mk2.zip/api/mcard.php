<?php
declare(strict_types=1);
// Инфографика для карточек Яндекс Маркета: собирается из фото и характеристик товара (PHP GD).
// Шаблоны: 'a' — тёмный, 'b' — светлый. Без цен, контактов и логотипа магазина (правила Маркета).
require_once __DIR__ . '/seo.php';

const MC_VER = 4;                 // поменять, чтобы пересобрать все карточки
const MC_W = 1200, MC_H = 1600, MC_S = 2;   // рисуем в 2× и уменьшаем — так ровнее края
function mc_font(string $n): string { return ROOT . '/api/fonts/' . $n . '.ttf'; }
function mc_tpl(): string { $t = (string)(content()['mcard_tpl'] ?? 'a'); return in_array($t, ['a', 'b'], true) ? $t : 'a'; }

function mc_col($im, string $hex, int $a = 0): int {
    $h = ltrim($hex, '#'); return imagecolorallocatealpha($im, hexdec(substr($h, 0, 2)), hexdec(substr($h, 2, 2)), hexdec(substr($h, 4, 2)), $a);
}
function mc_rrect($im, float $x, float $y, float $w, float $h, float $r, int $c): void {
    $s = MC_S; [$x, $y, $w, $h, $r] = [(int)($x * $s), (int)($y * $s), (int)($w * $s), (int)($h * $s), (int)($r * $s)];
    imagefilledrectangle($im, $x + $r, $y, $x + $w - $r, $y + $h, $c);
    imagefilledrectangle($im, $x, $y + $r, $x + $w, $y + $h - $r, $c);
    foreach ([[$x + $r, $y + $r], [$x + $w - $r, $y + $r], [$x + $r, $y + $h - $r], [$x + $w - $r, $y + $h - $r]] as [$cx, $cy]) imagefilledellipse($im, $cx, $cy, 2 * $r, 2 * $r, $c);
}
function mc_tw(float $size, string $font, string $s): float { $b = imagettfbbox($size * MC_S, 0, mc_font($font), $s); return ($b[2] - $b[0]) / MC_S; }
function mc_text($im, float $size, string $font, float $x, float $y, string $s, int $c): void { imagettftext($im, $size * MC_S, 0, (int)($x * MC_S), (int)($y * MC_S), $c, mc_font($font), $s); }
// уменьшает шрифт, пока строка не влезет в ширину
function mc_fit(float $size, string $font, string $s, float $w, float $min = 18): float { while ($size > $min && mc_tw($size, $font, $s) > $w) $size -= 2; return $size; }
function mc_wrap(float $size, string $font, string $s, float $w, int $max = 2): array {
    $out = []; $line = '';
    foreach (preg_split('/\s+/u', trim($s)) as $word) {
        $try = $line === '' ? $word : $line . ' ' . $word;
        if ($line !== '' && mc_tw($size, $font, $try) > $w) { $out[] = $line; $line = $word; } else $line = $try;
    }
    if ($line !== '') $out[] = $line;
    if (count($out) > $max) { $out = array_slice($out, 0, $max); $out[$max - 1] .= '…'; }
    return $out;
}
function mc_gradient($im, string $top, string $bot): void {
    $t = sscanf(ltrim($top, '#'), '%2x%2x%2x'); $b = sscanf(ltrim($bot, '#'), '%2x%2x%2x'); $H = MC_H * MC_S;
    for ($y = 0; $y < $H; $y += 2) { $k = $y / $H; imagefilledrectangle($im, 0, $y, MC_W * MC_S, $y + 1, imagecolorallocate($im, (int)($t[0] + ($b[0] - $t[0]) * $k), (int)($t[1] + ($b[1] - $t[1]) * $k), (int)($t[2] + ($b[2] - $t[2]) * $k))); }
}
function mc_glow($im, float $cx, float $cy, float $r, string $hex): void {
    for ($i = 30; $i >= 1; $i--) imagefilledellipse($im, (int)($cx * MC_S), (int)($cy * MC_S), (int)(2 * $r * $i / 30 * MC_S), (int)(2 * $r * $i / 30 * MC_S), mc_col($im, $hex, (int)(122 + $i / 30 * 5)));
}
// фото товара: обрезаем белые поля и вписываем в рамку
function mc_photo($im, string $file, float $x, float $y, float $w, float $h): bool {
    $src = @imagecreatefromstring((string)@file_get_contents($file)); if (!$src) return false;
    $sw = imagesx($src); $sh = imagesy($src); $x0 = $sw; $y0 = $sh; $x1 = 0; $y1 = 0; $st = max(1, (int)(min($sw, $sh) / 300));
    for ($yy = 0; $yy < $sh; $yy += $st) for ($xx = 0; $xx < $sw; $xx += $st) {
        $p = imagecolorat($src, $xx, $yy); $a = ($p >> 24) & 127; $r = ($p >> 16) & 255; $g = ($p >> 8) & 255; $b = $p & 255;
        if ($a < 100 && ($r < 238 || $g < 238 || $b < 238)) { $x0 = min($x0, $xx); $y0 = min($y0, $yy); $x1 = max($x1, $xx); $y1 = max($y1, $yy); }
    }
    if ($x1 <= $x0 || $y1 <= $y0) { $x0 = 0; $y0 = 0; $x1 = $sw - 1; $y1 = $sh - 1; }
    $cw = $x1 - $x0 + 1; $ch = $y1 - $y0 + 1; $k = min($w / $cw, $h / $ch);
    $dw = $cw * $k; $dh = $ch * $k; $dx = $x + ($w - $dw) / 2; $dy = $y + ($h - $dh) / 2;
    imagealphablending($im, true);
    imagecopyresampled($im, $src, (int)($dx * MC_S), (int)($dy * MC_S), $x0, $y0, (int)($dw * MC_S), (int)($dh * MC_S), $cw, $ch);
    imagedestroy($src); return true;
}

function mc_facts(array $x): array {
    $pol = ['R' => ['Обратная', '+ справа'], 'L' => ['Прямая', '+ слева'], '3' => ['Тип 3', 'грузовая'], '4' => ['Тип 4', 'грузовая']][$x['p']] ?? null;
    $f = [[(int)$x['c'] . ' Ач', 'ёмкость']];
    if (!empty($x['a'])) $f[] = [(int)$x['a'] . ' А', 'пусковой ток (EN)'];
    if ($pol) $f[] = [$pol[0], 'полярность, ' . $pol[1]];
    if (!empty($x['d'])) $f[] = [implode('×', $x['d']), 'габариты, мм'];
    if (count($f) < 4) $f[] = [$x['te'] === 'Ca/Ca' ? 'Ca/Ca' : $x['te'], 'технология'];
    return array_slice($f, 0, 4);
}
function mc_foot(array $x): string {
    $k = ['E' => 'Европейский корпус', 'A' => 'Азиатский корпус', 'T' => 'Грузовой корпус'][$x['k'] ?? ''] ?? '';
    $p = array_filter([$k, ($x['tm'] ?? '') && $x['tm'] !== 'Стандартные' ? 'клеммы: ' . mb_strtolower($x['tm']) : '', !empty($x['lo']) ? 'низкий' : '', !empty($x['gw']) ? 'гарантия ' . (int)$x['gw'] . ' мес.' : '']);
    return implode(' · ', $p);
}

function mc_render(array $x, string $tpl, string $photo) {
    $im = imagecreatetruecolor(MC_W * MC_S, MC_H * MC_S); imagealphablending($im, true); imageantialias($im, true);
    $series = short_title($x); if ($series === '' || preg_match('/^Аккумулятор/u', $series)) $series = 'Автомобильный аккумулятор'; $brand = mb_strtoupper((string)$x['b']); $tech = $x['te'] === 'Ca/Ca' ? 'Ca/Ca' : (string)$x['te'];
    $facts = mc_facts($x); $foot = mc_foot($x);
    if ($tpl === 'b') {
        imagefilledrectangle($im, 0, 0, MC_W * MC_S, MC_H * MC_S, mc_col($im, '#F2F3F5'));
        mc_rrect($im, 50, 50, 1100, 860, 48, mc_col($im, '#FFFFFF'));
        mc_photo($im, $photo, 110, 160, 980, 700);
        $tw = mc_tw(30, 'unbounded-700', $tech) + 56; mc_rrect($im, 90, 90, $tw, 64, 32, mc_col($im, '#F5A524')); mc_text($im, 30, 'unbounded-700', 118, 134, $tech, mc_col($im, '#16181D'));
        $bs = mc_fit(56, 'unbounded-700', $brand, 1080); mc_text($im, $bs, 'unbounded-700', 60, 1000, $brand, mc_col($im, '#16181D'));
        foreach (mc_wrap(38, 'onest-600', $series ?: 'Аккумулятор ' . (int)$x['c'] . ' Ач', 1080, 1) as $l) mc_text($im, 38, 'onest-600', 60, 1058, $l, mc_col($im, '#4A505C'));
        foreach ($facts as $i => [$v, $l]) {
            $bx = 50 + ($i % 2) * 556; $by = 1100 + intdiv($i, 2) * 206;
            mc_rrect($im, $bx, $by, 544, 190, 30, mc_col($im, '#FFFFFF')); mc_rrect($im, $bx + 34, $by + 30, 60, 10, 5, mc_col($im, '#F5A524'));
            $vs = mc_fit(52, 'unbounded-700', $v, 476, 24); mc_text($im, $vs, 'unbounded-700', $bx + 34, $by + 110, $v, mc_col($im, '#16181D'));
            mc_text($im, mc_fit(28, 'onest-400', $l, 476), 'onest-400', $bx + 34, $by + 158, $l, mc_col($im, '#6B7280'));
        }
        if ($foot) mc_text($im, mc_fit(30, 'onest-600', $foot, 1080), 'onest-600', 60, 1560, $foot, mc_col($im, '#4A505C'));
    } else {
        mc_gradient($im, '#232731', '#0D0F13');
        mc_glow($im, 600, 720, 620, '#F5A524');
        $bs = mc_fit(60, 'unbounded-700', $brand, 760); mc_text($im, $bs, 'unbounded-700', 80, 150, $brand, mc_col($im, '#F5A524'));
        $y = 222; foreach (mc_wrap(46, 'onest-700', $series ?: 'Аккумулятор ' . (int)$x['c'] . ' Ач', 1040, 2) as $l) { mc_text($im, 46, 'onest-700', 80, $y, $l, mc_col($im, '#FFFFFF')); $y += 58; }
        $tw = mc_tw(30, 'unbounded-700', $tech) + 56; mc_rrect($im, 1120 - $tw, 96, $tw, 68, 34, mc_col($im, '#F5A524')); mc_text($im, 30, 'unbounded-700', 1120 - $tw + 28, 142, $tech, mc_col($im, '#16181D'));
        mc_rrect($im, 80, 330, 1040, 720, 44, mc_col($im, '#FFFFFF'));
        mc_photo($im, $photo, 130, 370, 940, 640);
        foreach ($facts as $i => [$v, $l]) {
            $bx = 80 + ($i % 2) * 530; $by = 1090 + intdiv($i, 2) * 220;
            mc_rrect($im, $bx, $by, 510, 200, 32, mc_col($im, '#262B35'));
            mc_rrect($im, $bx + 34, $by + 34, 8, 132, 4, mc_col($im, '#F5A524'));
            $vs = mc_fit(56, 'unbounded-700', $v, 420, 24); mc_text($im, $vs, 'unbounded-700', $bx + 66, $by + 104, $v, mc_col($im, '#FFFFFF'));
            mc_text($im, mc_fit(28, 'onest-400', $l, 420), 'onest-400', $bx + 66, $by + 152, $l, mc_col($im, '#A2A8B3'));
        }
        if ($foot) mc_text($im, mc_fit(30, 'onest-600', $foot, 1040), 'onest-600', 80, 1560, $foot, mc_col($im, '#A2A8B3'));
    }
    $out = imagecreatetruecolor(MC_W, MC_H);
    imagecopyresampled($out, $im, 0, 0, 0, 0, MC_W, MC_H, MC_W * MC_S, MC_H * MC_S); imagedestroy($im);
    return $out;
}

// ключ карточки: меняется, когда меняются данные товара, фото или шаблон
function mc_hash(array $x, ?string $tpl = null): string {
    $k = [$x['b'], $x['t'], $x['c'], $x['a'] ?? '', $x['p'], $x['k'] ?? '', $x['tm'] ?? '', $x['te'], $x['lo'] ?? 0, $x['d'] ?? '', $x['gw'] ?? '', $x['img'] ?? '', $tpl ?? mc_tpl(), MC_VER];
    return substr(md5(json_encode($k, JSON_UNESCAPED_UNICODE)), 0, 8);
}
function mc_url(array $x): string { return site_url() . '/mcard/' . $x['id'] . '-' . mc_hash($x) . '.jpg'; }
// путь к готовому файлу (собирает при необходимости)
function mc_file(array $x, ?string $tpl = null): ?string {
    if (empty($x['img']) || !is_file(ROOT . '/' . $x['img'])) return null;
    $tpl ??= mc_tpl(); $dir = ROOT . '/uploads/mcard'; @mkdir($dir, 0755, true);
    $f = $dir . '/' . $x['id'] . '-' . mc_hash($x, $tpl) . '.jpg';
    if (!is_file($f)) {
        foreach (glob($dir . '/' . $x['id'] . '-*.jpg') ?: [] as $old) @unlink($old);
        $im = mc_render($x, $tpl, ROOT . '/' . $x['img']); imagejpeg($im, $f . '.tmp', 88); imagedestroy($im); rename($f . '.tmp', $f);
    }
    return $f;
}
