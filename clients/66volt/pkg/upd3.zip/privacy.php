<?php
require __DIR__ . '/api/content.php';
serve_page(__DIR__ . '/privacy.tpl.html');
