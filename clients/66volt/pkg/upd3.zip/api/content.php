<?php
declare(strict_types=1);
// Редактируемое содержимое сайта: тексты, контакты, вопросы, доп. блоки, описания брендов и технологий, подбор по авто.
// Значения по умолчанию — content-defaults.json (собирается build_prod.py), правки из админки — content.json.
require_once __DIR__ . '/lib.php';

// Типоразмеры для подбора по авто: [длина, ширина, высота, Ач от, Ач до]
const CAR_GROUPS = [
    'E1' => [207, 175, 190, 45, 62], 'E1L' => [207, 175, 175, 45, 62], 'E2' => [242, 175, 190, 55, 66], 'E2L' => [242, 175, 175, 55, 66],
    'E3' => [278, 175, 190, 70, 77], 'E3L' => [278, 175, 175, 70, 77], 'E4' => [315, 175, 190, 80, 88], 'E4L' => [315, 175, 175, 80, 88],
    'E5' => [353, 175, 190, 90, 100], 'E6' => [393, 175, 190, 100, 110],
    'A19' => [187, 127, 227, 40, 45], 'A24' => [238, 129, 227, 45, 60], 'A23' => [232, 173, 225, 55, 70], 'A26' => [260, 173, 225, 70, 80], 'A31' => [306, 173, 225, 90, 110],
    'T190' => [513, 223, 223, 180, 200], 'T225' => [518, 276, 242, 210, 240],
];
const CAR_GNAME = ['E1' => 'L1', 'E1L' => 'LB1 низкий', 'E2' => 'L2', 'E2L' => 'LB2 низкий', 'E3' => 'L3', 'E3L' => 'LB3 низкий', 'E4' => 'L4', 'E4L' => 'LB4 низкий',
    'E5' => 'L5', 'E6' => 'L6', 'A19' => 'B19', 'A24' => 'B24', 'A23' => 'D23', 'A26' => 'D26', 'A31' => 'D31', 'T190' => 'Грузовой 190', 'T225' => 'Грузовой 225'];
const CAR_POL = ['R' => 'Обратная', 'L' => 'Прямая', 'RL' => 'Бывает разной', '3' => 'Грузовая тип 3', '4' => 'Грузовая тип 4', '34' => 'Грузовая 3 или 4'];

function json_file(string $f): array { return json_decode((string)@file_get_contents($f), true) ?: []; }
function json_save(string $f, array $d): void {
    $tmp = $f . '.tmp';
    file_put_contents($tmp, json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), LOCK_EX);
    rename($tmp, $f);
}
function content_defaults(): array { static $d = null; return $d ??= json_file(ROOT . '/content-defaults.json'); }
function content(): array { static $c = null; return $c ??= json_file(ROOT . '/content.json'); }
function save_content(array $c): void { json_save(ROOT . '/content.json', $c); }

function ct(string $k): string {
    $v = content()['texts'][$k] ?? '';
    if ($v === ' ') return '';   // явно очищено (например, второй телефон)
    return trim((string)$v) !== '' ? (string)$v : (string)(content_defaults()['texts'][$k]['v'] ?? '');
}
function ct_list(string $k): array { $c = content(); return array_key_exists($k, $c) ? (array)$c[$k] : (array)(content_defaults()[$k] ?? []); }
function ct_map(string $k): array { return array_merge((array)(content_defaults()[$k] ?? []), array_filter((array)(content()[$k] ?? []), fn($v) => trim((string)$v) !== '')); }

function esc_t(string $s): string { return nl2br(htmlspecialchars($s, ENT_QUOTES, 'UTF-8'), false); }
function tel_href(string $p): string { $d = preg_replace('/\D/', '', $p); if (strlen($d) === 11 && $d[0] === '8') $d = '7' . substr($d, 1); return $d ? '+' . $d : ''; }

// ---- подбор по авто ----
function car_rows(): array { return json_file(ROOT . '/cars.json')['cars'] ?? []; }
function save_car_rows(array $cars): void { json_save(ROOT . '/cars.json', ['cars' => $cars]); }
// Превращает строки (марка → [модель, поколение, типоразмеры, полярность, старт-стоп]) в формат витрины
function cars_js(): string {
    $out = [];
    foreach (car_rows() as $mk => $rows) {
        $models = [];
        foreach ($rows as $r) {
            $m = trim((string)($r['m'] ?? '')); $gr = trim((string)($r['gr'] ?? ''));
            if ($m === '' || $gr === '') continue;
            $models[$m][] = $r;
        }
        $list = [];
        foreach ($models as $m => $rs) {
            if (count($rs) === 1 && trim((string)$rs[0]['g']) === '') { $list[] = [$m, $rs[0]['gr'], $rs[0]['p'], (int)$rs[0]['ss']]; continue; }
            $list[] = [$m, array_map(fn($r) => [trim((string)$r['g']) !== '' ? (string)$r['g'] : 'все годы', $r['gr'], $r['p'], (int)$r['ss']], $rs)];
        }
        if ($list) $out[$mk] = $list;
    }
    $f = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP;
    return 'const GROUPS=' . json_encode(CAR_GROUPS, $f) . ';const CARS=' . json_encode($out ?: new stdClass(), $f) . ';';
}

// ---- сборка страницы ----
function render_page(string $tplFile): string {
    $html = (string)file_get_contents($tplFile);
    $d = content_defaults();
    $map = [];
    foreach (($d['texts'] ?? []) as $k => $meta) {
        $v = ct($k);
        $map['{{t:' . $k . '}}'] = !empty($meta['line']) ? htmlspecialchars(str_replace(["\r", "\n"], ' ', $v), ENT_QUOTES, 'UTF-8') : esc_t($v);
    }
    $p2 = ct('phone2');
    $map['{{phone_tel}}'] = tel_href(ct('phone'));
    $map['{{phone2_tel}}'] = tel_href($p2);
    $map['{{phone2_comma}}'] = $p2 !== '' ? ', ' . htmlspecialchars($p2) : '';
    $map['{{phone2_link}}'] =$p2 !== '' ? ' · <a href="tel:' . tel_href($p2) . '">' . htmlspecialchars($p2) . '</a>' : '';
    $map['{{address_url}}'] = 'https://yandex.ru/maps/?text=' . rawurlencode(ct('address'));
    // вопросы и ответы
    $faq = '';
    foreach (ct_list('faq') as $qa) {
        if (trim((string)($qa['q'] ?? '')) === '') continue;
        $faq .= '<div class="qa"><button type="button" aria-expanded="false">' . htmlspecialchars((string)$qa['q']) . '<svg width="18" height="18" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.4" fill="none"><path d="M12 4v16M4 12h16"/></svg></button><div class="ans"><div><p>' . esc_t((string)($qa['a'] ?? '')) . '</p></div></div></div>';
    }
    $map['{{faq}}'] = $faq;
    // дополнительные блоки
    $ex = '';
    foreach (ct_list('extra') as $i => $b) {
        if (trim((string)($b['t'] ?? '')) === '' && trim((string)($b['x'] ?? '')) === '') continue;
        $ex .= '<section id="block' . ($i + 1) . '" style="padding-top:0"><div class="wrap"><div class="sh rv">' . (trim((string)$b['t']) !== '' ? '<h2>' . htmlspecialchars((string)$b['t']) . '</h2>' : '') .
            '<p>' . esc_t((string)($b['x'] ?? '')) . '</p></div></div></section>';
    }
    $map['{{extra}}'] = $ex;
    // скрытые блоки
    $css = '';
    foreach ((array)(content()['hide'] ?? []) as $sec => $on) if ($on && preg_match('/^[a-z]+$/', (string)$sec)) $css .= '#' . $sec . ',a[href="#' . $sec . '"]{display:none!important}';
    $map['{{hide_css}}'] = $css ? '<style>' . $css . '</style>' : '';
    // Яндекс Метрика
    $mid = preg_replace('/\D/', '', ct('metrika'));
    $map['{{metrika}}'] = $mid ? '<script>(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})(window,document,"script","https://mc.yandex.ru/metrika/tag.js","ym");ym(' . $mid . ',"init",{clickmap:true,trackLinks:true,accurateTrackBounce:true,webvisor:true});</script><noscript><div><img src="https://mc.yandex.ru/watch/' . $mid . '" style="position:absolute;left:-9999px" alt=""></div></noscript>' : '';
    // описания брендов и технологий для карточки товара
    $map['{{ct_json}}'] = json_encode(['brands' => ct_map('brands'), 'techs' => ct_map('techs')], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);
    if (str_contains($html, '{{cars_js}}')) $map['{{cars_js}}'] = cars_js();
    return strtr($html, $map);
}

function serve_page(string $tplFile): void {
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-cache');
    echo render_page($tplFile);
}
