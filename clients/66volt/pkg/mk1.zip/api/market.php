<?php
declare(strict_types=1);
// Выгрузка каталога для Яндекс Маркета (YML). В выгрузку попадают видимые товары с ценой и фото.
require_once __DIR__ . '/mcard.php';

function mk_items(): array { return array_values(array_filter(pub_items(), fn($x) => !empty($x['img']) && is_file(ROOT . '/' . $x['img']))); }
function mk_pol(string $p): string { return ['R' => 'обратная', 'L' => 'прямая', '3' => 'тип 3', '4' => 'тип 4'][$p] ?? ''; }
function mk_name(array $x): string {
    $s = 'Аккумулятор автомобильный ' . trim($x['b'] . ' ' . short_title($x)) . ' ' . (int)$x['c'] . ' Ач';
    if (!empty($x['a'])) $s .= ' ' . (int)$x['a'] . ' А';
    if ($p = mk_pol((string)$x['p'])) $s .= ' ' . ($p === 'обратная' || $p === 'прямая' ? $p . ' полярность' : $p);
    if (!empty($x['d'])) $s .= ' ' . implode('x', $x['d']);
    return $s;
}
function mk_desc(array $x): string {
    $f = ['ёмкость ' . (int)$x['c'] . ' Ач'];
    if (!empty($x['a'])) $f[] = 'пусковой ток ' . (int)$x['a'] . ' А (EN)';
    if ($p = mk_pol((string)$x['p'])) $f[] = 'полярность ' . $p . (in_array($x['p'], ['R', 'L'], true) ? ($x['p'] === 'R' ? ' (+ справа)' : ' (+ слева)') : '');
    if (!empty($x['d'])) $f[] = 'габариты ' . implode('×', $x['d']) . ' мм';
    $k = ['E' => 'европейский корпус', 'A' => 'азиатский корпус', 'T' => 'грузовой корпус'][$x['k'] ?? ''] ?? ''; if ($k) $f[] = $k;
    $f[] = 'технология ' . te_name((string)$x['te']);
    if (!empty($x['gw'])) $f[] = 'гарантия ' . (int)$x['gw'] . ' мес.';
    $s = 'Аккумулятор ' . item_name($x) . ': ' . rtrim(implode(', ', $f), '.') . '.';
    if (!empty($x['ds'])) $s .= "\n\n" . trim((string)$x['ds']);
    if ($bd = ct_map('brands')[$x['b']] ?? '') $s .= "\n\n" . trim(strip_tags((string)$bd));
    if ($td = ct_map('techs')[te_name((string)$x['te'])] ?? '') $s .= "\n\n" . trim(strip_tags((string)$td));
    return $s;
}
function mk_x(string $s): string { return htmlspecialchars($s, ENT_XML1 | ENT_QUOTES, 'UTF-8'); }
function mk_yml(): string {
    $base = site_url();
    $o = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<yml_catalog date="' . date('Y-m-d\TH:i:sP') . '"><shop><name>66 Вольт</name><company>66 Вольт</company><url>' . $base . '/</url>'
        . '<currencies><currency id="RUR" rate="1"/></currencies><categories><category id="1">Аккумуляторы автомобильные</category></categories><offers>' . "\n";
    foreach (mk_items() as $x) {
        $pics = [$base . '/' . $x['img'], mc_url($x)];
        if (!empty($x['mk']) && is_file(ROOT . '/' . $x['mk'])) $pics[] = $base . '/' . $x['mk'];
        $o .= '<offer id="' . mk_x($x['id']) . '" available="true"><name>' . mk_x(mk_name($x)) . '</name><vendor>' . mk_x((string)$x['b']) . '</vendor>'
            . '<url>' . $base . item_url($x) . '</url><price>' . (int)$x['pr'] . '</price><currencyId>RUR</currencyId><categoryId>1</categoryId>';
        foreach ($pics as $p) $o .= '<picture>' . mk_x($p) . '</picture>';
        $o .= '<description><![CDATA[' . str_replace(']]>', ']]&gt;', mk_desc($x)) . ']]></description>';
        if (!empty($x['mf'])) $o .= '<manufacturer>' . mk_x((string)$x['mf']) . '</manufacturer>';
        $prm = ['Ёмкость' => [(int)$x['c'], 'А·ч'], 'Пусковой ток' => [!empty($x['a']) ? (int)$x['a'] : null, 'А'], 'Полярность' => [mk_pol((string)$x['p']) ?: null, ''],
            'Технология' => [te_name((string)$x['te']), ''], 'Тип корпуса' => [['E' => 'европейский', 'A' => 'азиатский', 'T' => 'грузовой'][$x['k'] ?? ''] ?? null, ''],
            'Тип клемм' => [$x['tm'] ?? null, ''], 'Длина' => [$x['d'][0] ?? null, 'мм'], 'Ширина' => [$x['d'][1] ?? null, 'мм'], 'Высота' => [$x['d'][2] ?? null, 'мм'],
            'Напряжение' => [12, 'В'], 'Гарантийный срок' => [!empty($x['gw']) ? (int)$x['gw'] : null, 'мес.']];
        foreach ($prm as $n => [$v, $u]) if ($v !== null && $v !== '') $o .= '<param name="' . mk_x($n) . '"' . ($u ? ' unit="' . mk_x($u) . '"' : '') . '>' . mk_x((string)$v) . '</param>';
        if (!empty($x['d'])) $o .= '<dimensions>' . implode('/', array_map(fn($v) => number_format($v / 10, 1, '.', ''), $x['d'])) . '</dimensions>';
        if (isset($x['s']) && $x['s'] !== null && $x['s'] !== '') $o .= '<count>' . max(0, (int)$x['s']) . '</count>';
        $o .= "</offer>\n";
    }
    return $o . '</offers></shop></yml_catalog>';
}
