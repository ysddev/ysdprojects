<?php
require __DIR__ . '/api/market.php';
header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: no-cache');
echo mk_yml();
