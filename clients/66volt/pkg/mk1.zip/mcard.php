<?php
// Картинка-инфографика товара для Яндекс Маркета: /mcard/AKB-0001-<ключ>.jpg
require __DIR__ . '/api/mcard.php';
$id = (string)($_GET['id'] ?? ''); $h = (string)($_GET['h'] ?? '');
$x = preg_match('/^AKB-\d{4,6}$/', $id) ? (catalog_by_id()[$id] ?? null) : null;
if (!$x || !empty($x['h']) || empty($x['img']) || !is_file(ROOT . '/' . $x['img'])) { http_response_code(404); exit; }
if ($h !== mc_hash($x)) { header('Location: ' . mc_url($x), true, 302); exit; }
@set_time_limit(60); ini_set('memory_limit', '256M');
$f = mc_file($x);
if (!$f) { http_response_code(404); exit; }
header('Content-Type: image/jpeg'); header('Cache-Control: public, max-age=604800'); header('Content-Length: ' . filesize($f));
readfile($f);
