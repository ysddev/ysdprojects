<?php
declare(strict_types=1);
require __DIR__ . '/../api/lib.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict', 'secure' => !empty($_SERVER['HTTPS'])]);
session_name('v66adm');
session_start();
header('X-Frame-Options: DENY');
header('Cache-Control: no-store');

function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(16)); }
function check_csrf(): void { if (!hash_equals(csrf(), (string)($_POST['csrf'] ?? ''))) { http_response_code(400); exit('Обновите страницу'); } }
function go(string $q): void { header('Location: ?' . $q); exit; }

// ---- вход ----
if (isset($_GET['logout'])) { session_destroy(); go(''); }
if (empty($_SESSION['ok'])) {
    $msg = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        usleep(400000);
        $hash = (string)cfg('admin_hash', '');
        if ($hash !== '' && password_verify((string)($_POST['pass'] ?? ''), $hash)) { session_regenerate_id(true); $_SESSION['ok'] = 1; go('p=orders'); }
        $msg = $hash === '' ? 'Пароль админки не задан в data/config.php' : 'Неверный пароль';
    }
    page('Вход', '<form method="post" class="box narrow"><h1>66 Вольт — админка</h1>' . ($msg ? '<p class="err">' . h($msg) . '</p>' : '') .
        '<label>Пароль<input type="password" name="pass" autofocus required></label><button>Войти</button></form>');
}

$p = $_GET['p'] ?? 'orders';
if ($_SERVER['REQUEST_METHOD'] === 'POST') { check_csrf(); handle_post($p); }

if ($p === 'products') products(); elseif ($p === 'diag') diag(); else orders();

// ---------------- действия ----------------
function handle_post(string $p): void {
    $a = $_POST['a'] ?? '';
    if ($a === 'status') {
        $allowed = ['new', 'awaiting_payment', 'paid', 'done', 'cancelled', 'request', 'payment_error', 'rejected', 'refunded'];
        $s = $_POST['status'] ?? '';
        if (in_array($s, $allowed, true)) db()->prepare('UPDATE orders SET status=? WHERE id=?')->execute([$s, (int)$_POST['id']]);
        go('p=orders');
    }
    if ($a === 'save' || $a === 'photo' || $a === 'nophoto' || $a === 'add') {
        $items = catalog();
        if ($a === 'add') {
            $ids = array_map(fn($x) => (int)substr($x['id'], 4), $items);
            $new = ['id' => sprintf('AKB-%04d', max($ids ?: [0]) + 1), 'b' => clean($_POST['b'] ?? '', 40), 't' => clean($_POST['t'] ?? '', 120),
                'c' => (int)($_POST['c'] ?? 0), 'a' => ((int)($_POST['a2'] ?? 0)) ?: null, 'd' => null, 'p' => in_array($_POST['pol'] ?? '', ['R', 'L', '3', '4'], true) ? $_POST['pol'] : '?',
                'k' => in_array($_POST['k'] ?? '', ['E', 'A', 'T'], true) ? $_POST['k'] : 'E', 'tm' => 'Стандартные', 'te' => in_array($_POST['te'] ?? '', ['Стандарт', 'EFB', 'AGM', 'Ca/Ca'], true) ? $_POST['te'] : 'Стандарт',
                'lo' => 0, 's' => null, 'pr' => max(0, (int)($_POST['pr'] ?? 0)), 'mf' => clean($_POST['mf'] ?? '', 80)];
            $L = (int)($_POST['L'] ?? 0); $W = (int)($_POST['W'] ?? 0); $H = (int)($_POST['H'] ?? 0);
            if ($L && $W && $H) $new['d'] = [$L, $W, $H];
            if ($new['b'] && $new['c'] && $new['pr']) { $items[] = $new; save_catalog($items); }
            go('p=products&q=' . urlencode($new['id']));
        }
        $id = (string)($_POST['id'] ?? '');
        foreach ($items as &$x) {
            if ($x['id'] !== $id) continue;
            if ($a === 'save') {
                $x['pr'] = max(0, (int)preg_replace('/\D/', '', (string)($_POST['pr'] ?? $x['pr'])));
                $x['h'] = !empty($_POST['h']) ? 1 : 0;
                $x['mf'] = clean($_POST['mf'] ?? ($x['mf'] ?? ''), 80);
                $x['t'] = clean($_POST['t'] ?? $x['t'], 120) ?: $x['t'];
            } elseif ($a === 'photo' && !empty($_FILES['img']['tmp_name']) && $_FILES['img']['size'] < 6_000_000) {
                $info = @getimagesize($_FILES['img']['tmp_name']);
                $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$info['mime'] ?? ''] ?? null;
                if ($ext) {
                    @mkdir(ROOT . '/uploads', 0755);
                    $fn = 'uploads/' . strtolower($x['id']) . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
                    if (move_uploaded_file($_FILES['img']['tmp_name'], ROOT . '/' . $fn)) {
                        if (!empty($x['img']) && str_starts_with($x['img'], 'uploads/')) @unlink(ROOT . '/' . $x['img']);
                        $x['img'] = $fn;
                    }
                }
            } elseif ($a === 'nophoto') {
                if (!empty($x['img']) && str_starts_with($x['img'], 'uploads/')) @unlink(ROOT . '/' . $x['img']);
                unset($x['img']);
            }
        }
        unset($x);
        save_catalog($items);
        go('p=products&q=' . urlencode((string)($_POST['q'] ?? '')) . '#' . urlencode($id));
    }
    if ($a === 'testmail') {
        $ok = send_mail('Проверка почты — 66 Вольт', 'Если вы видите это письмо, уведомления о заказах будут приходить сюда.');
        $_SESSION['flash'] = $ok ? 'Письмо отправлено на ' . cfg('shop_email') . ' — проверьте почту (и папку «Спам»).' : 'Не удалось отправить письмо: функция mail() на хостинге не сработала.';
        go('p=diag');
    }
    if ($a === 'testmax') {
        $_SESSION['flash'] = send_max('Проверка уведомлений — 66 Вольт') ? 'Сообщение в Max отправлено.' : 'Max не настроен или токен неверный.';
        go('p=diag');
    }
    go('p=' . $p);
}

// ---------------- страницы ----------------
function nav(string $cur): string {
    $l = ['orders' => 'Заказы и заявки', 'products' => 'Товары и цены', 'diag' => 'Проверка'];
    $s = '<nav>'; foreach ($l as $k => $t) $s .= '<a href="?p=' . $k . '"' . ($k === $cur ? ' class="on"' : '') . '>' . $t . '</a>';
    return $s . '<a href="../" target="_blank">Сайт ↗</a><a href="?logout=1">Выйти</a></nav>';
}

function orders(): void {
    $rows = db()->query('SELECT * FROM orders ORDER BY id DESC LIMIT 300')->fetchAll();
    $sts = ['new', 'awaiting_payment', 'paid', 'done', 'cancelled', 'payment_error', 'rejected', 'refunded', 'request'];
    $o = nav('orders') . '<div class="box"><h1>Заказы и заявки</h1>';
    if (!$rows) $o .= '<p class="muted">Пока пусто. Новые заказы и заявки появятся здесь и придут на почту.</p>';
    foreach ($rows as $r) {
        $items = json_decode($r['items'], true) ?: [];
        $o .= '<div class="ord st-' . h($r['status']) . '"><div class="oh"><b>' . ($r['kind'] === 'request' ? 'Заявка на подбор' : 'Заказ') . ' №' . (int)$r['id'] . '</b><span>' . h($r['created']) . '</span>';
        $o .= '<form method="post"><input type="hidden" name="csrf" value="' . csrf() . '"><input type="hidden" name="a" value="status"><input type="hidden" name="id" value="' . (int)$r['id'] . '"><select name="status" onchange="this.form.submit()">';
        foreach ($sts as $s) $o .= '<option value="' . $s . '"' . ($s === $r['status'] ? ' selected' : '') . '>' . h(status_name($s)) . '</option>';
        $o .= '</select></form></div>';
        if ($r['kind'] === 'request') {
            $o .= '<p>Авто: <b>' . h($r['note']) . '</b><br>Телефон: <a href="tel:' . h($r['phone']) . '">' . h($r['phone']) . '</a></p>';
        } else {
            $o .= '<ul>'; foreach ($items as $it) $o .= '<li>' . h($it['name']) . ' × ' . (int)$it['q'] . ' — ' . rub((int)$it['sum']) . '</li>'; $o .= '</ul>';
            $o .= '<p><b>Итого: ' . rub((int)$r['total']) . '</b><br>' . h($r['name']) . ', <a href="tel:' . h($r['phone']) . '">' . h($r['phone']) . '</a>' . ($r['email'] ? ', ' . h($r['email']) : '') .
                '<br>' . ($r['dlv'] === 'courier' ? 'Курьер: ' . h($r['addr']) : 'Самовывоз из ПВЗ') . ' · ' . ($r['pay'] === 'online' ? 'оплата на сайте' : 'оплата при получении') .
                ($r['note'] ? '<br><span class="muted">' . h($r['note']) . '</span>' : '') . '</p>';
        }
        $o .= '</div>';
    }
    page('Заказы', $o . '</div>');
}

function products(): void {
    $q = trim((string)($_GET['q'] ?? '')); $ql = mb_strtolower($q);
    $all = catalog();
    $list = $q === '' ? array_slice($all, 0, 60) : array_values(array_filter($all, fn($x) => str_contains(mb_strtolower($x['id'] . ' ' . $x['b'] . ' ' . $x['t'] . ' ' . $x['c'] . 'ач'), $ql)));
    $c = csrf();
    $o = nav('products') . '<div class="box"><h1>Товары и цены</h1><form class="search"><input type="hidden" name="p" value="products"><input name="q" value="' . h($q) . '" placeholder="Поиск: бренд, модель, ёмкость, артикул (например «Тюмень 60»)"><button>Найти</button></form>';
    $o .= '<p class="muted">Всего товаров: ' . count($all) . '. Показано: ' . count($list) . ($q === '' ? ' (введите запрос, чтобы найти нужный)' : '') . '. Цена — розничная, в рублях. «Скрыть» убирает товар с сайта.</p>';
    foreach ($list as $x) {
        $o .= '<div class="prod" id="' . h($x['id']) . '"><div class="ph">' . (!empty($x['img']) ? '<img src="../' . h($x['img']) . '" alt="">' : '<span>нет фото</span>') . '</div><div class="pf">';
        $o .= '<div class="muted">' . h($x['id']) . ' · ' . h($x['b']) . ' · ' . (int)$x['c'] . ' Ач' . ($x['a'] ? ' · ' . (int)$x['a'] . ' А' : '') . ($x['d'] ? ' · ' . h(implode('×', $x['d'])) : '') . '</div>';
        $o .= '<form method="post" class="row"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="save"><input type="hidden" name="id" value="' . h($x['id']) . '"><input type="hidden" name="q" value="' . h($q) . '">' .
            '<label class="w">Название<input name="t" value="' . h($x['t']) . '"></label><label>Цена, ₽<input name="pr" inputmode="numeric" value="' . (int)$x['pr'] . '"></label>' .
            '<label class="w">Производитель<input name="mf" value="' . h($x['mf'] ?? '') . '"></label><label class="ck"><input type="checkbox" name="h" value="1"' . (!empty($x['h']) ? ' checked' : '') . '> Скрыть</label><button>Сохранить</button></form>';
        $o .= '<form method="post" enctype="multipart/form-data" class="row"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="photo"><input type="hidden" name="id" value="' . h($x['id']) . '"><input type="hidden" name="q" value="' . h($q) . '"><input type="file" name="img" accept="image/jpeg,image/png,image/webp" required><button class="ghost">Загрузить фото</button></form>';
        if (!empty($x['img'])) $o .= '<form method="post" class="row"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="nophoto"><input type="hidden" name="id" value="' . h($x['id']) . '"><input type="hidden" name="q" value="' . h($q) . '"><button class="ghost">Удалить фото</button></form>';
        $o .= '</div></div>';
    }
    $o .= '<details class="add"><summary>Добавить новый аккумулятор</summary><form method="post" class="grid"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="add">' .
        '<label>Бренд<input name="b" required></label><label>Название / серия<input name="t" required></label><label>Ёмкость, Ач<input name="c" inputmode="numeric" required></label><label>Ток, А (EN)<input name="a2" inputmode="numeric"></label>' .
        '<label>Длина<input name="L" inputmode="numeric"></label><label>Ширина<input name="W" inputmode="numeric"></label><label>Высота<input name="H" inputmode="numeric"></label>' .
        '<label>Полярность<select name="pol"><option value="R">Обратная</option><option value="L">Прямая</option><option value="3">Грузовая тип 3</option><option value="4">Грузовая тип 4</option></select></label>' .
        '<label>Корпус<select name="k"><option value="E">Европейский</option><option value="A">Азиатский</option><option value="T">Грузовой</option></select></label>' .
        '<label>Технология<select name="te"><option>Стандарт</option><option>EFB</option><option>AGM</option><option>Ca/Ca</option></select></label>' .
        '<label>Цена, ₽<input name="pr" inputmode="numeric" required></label><label>Производитель<input name="mf"></label><button>Добавить</button></form></details>';
    page('Товары', $o . '</div>');
}

function diag(): void {
    $flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
    $c = csrf();
    $chk = [];
    $chk[] = ['PHP', PHP_VERSION, version_compare(PHP_VERSION, '8.0', '>=')];
    $chk[] = ['Папка data доступна для записи', is_writable(DATA) ? 'да' : 'нет', is_writable(DATA)];
    $chk[] = ['Каталог', count(catalog()) . ' товаров', count(catalog()) > 0];
    $chk[] = ['Почта для заказов', (string)cfg('shop_email'), (bool)cfg('shop_email')];
    $term = (string)cfg('tbank_terminal');
    $chk[] = ['Терминал Т-Банка', $term ? (str_ends_with($term, 'DEMO') ? 'ТЕСТОВЫЙ (оплаты не настоящие)' : 'рабочий') : 'не задан', (bool)$term];
    // связь с API банка (без создания платежа)
    $ch = curl_init(rtrim((string)cfg('tbank_api'), '/') . '/GetState');
    $opt = [CURLOPT_POST => true, CURLOPT_POSTFIELDS => '{}', CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15];
    if (cfg('tbank_cainfo')) $opt[CURLOPT_CAINFO] = cfg('tbank_cainfo');
    curl_setopt_array($ch, $opt); $r = curl_exec($ch); $err = curl_error($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $chk[] = ['Связь с API Т-Банка (TLS)', $r === false ? 'ошибка: ' . $err : "есть (HTTP $code)", $r !== false];
    $chk[] = ['Max', cfg('max_token') ? 'настроен' : 'не настроен — уведомления только на почту', (bool)cfg('max_token')];
    $o = nav('diag') . '<div class="box"><h1>Проверка</h1>' . ($flash ? '<p class="ok">' . h($flash) . '</p>' : '') . '<table>';
    foreach ($chk as [$n, $v, $ok]) $o .= '<tr><td>' . h($n) . '</td><td class="' . ($ok ? 'g' : 'r') . '">' . h($v) . '</td></tr>';
    $o .= '</table><div class="row"><form method="post"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="testmail"><button>Отправить тестовое письмо</button></form>' .
        '<form method="post"><input type="hidden" name="csrf" value="' . $c . '"><input type="hidden" name="a" value="testmax"><button class="ghost">Проверить Max</button></form></div></div>';
    page('Проверка', $o);
}

function page(string $title, string $body, bool $exit = true): void {
    echo '<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . h($title) . ' — 66 Вольт</title><style>
*{box-sizing:border-box}body{margin:0;font:15px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#F4F5F7;color:#1B1D22}
nav{display:flex;flex-wrap:wrap;gap:4px;padding:10px 16px;background:#16181D}nav a{color:#C3C7CF;text-decoration:none;padding:10px 12px;border-radius:9px}nav a.on{background:#F5A524;color:#16181D;font-weight:600}
.box{max-width:1000px;margin:16px auto;background:#fff;border-radius:16px;padding:20px}.narrow{max-width:360px;margin-top:12vh}h1{font-size:22px;margin:0 0 14px}
label{display:flex;flex-direction:column;gap:4px;font-size:13px;color:#545A66}input,select{font:inherit;padding:10px 12px;border:1.5px solid #E3E5EA;border-radius:10px;min-height:44px;color:#1B1D22;background:#fff}
button{font:inherit;font-weight:600;min-height:44px;padding:0 16px;border:0;border-radius:10px;background:#F5A524;color:#16181D;cursor:pointer}button.ghost{background:#F4F5F7}
.err{color:#C0392B}.ok{background:#E3F4EA;color:#1E6B3E;padding:10px 12px;border-radius:10px}.muted{color:#7A808A;font-size:13.5px}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end;margin-top:8px}.row label.w{flex:1;min-width:200px}.row label.ck{flex-direction:row;align-items:center;min-height:44px}
.search{display:flex;gap:8px;margin-bottom:8px}.search input{flex:1}
.prod{display:flex;gap:14px;padding:14px 0;border-top:1px solid #E3E5EA}.ph{flex:0 0 96px;height:96px;border-radius:12px;background:#F4F5F7;display:grid;place-items:center;overflow:hidden;font-size:12px;color:#9AA0AA}.ph img{width:100%;height:100%;object-fit:contain}.pf{flex:1;min-width:0}
.ord{border:1.5px solid #E3E5EA;border-radius:14px;padding:12px 14px;margin-bottom:10px}.oh{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.oh span{color:#7A808A;font-size:13px}.oh form{margin-left:auto}
.ord.st-new,.ord.st-request{border-color:#F5A524}.ord.st-paid{border-color:#1E8E4E}.ord.st-payment_error,.ord.st-rejected{border-color:#D93A2B}ul{margin:8px 0;padding-left:18px}
table{width:100%;border-collapse:collapse}td{padding:10px 6px;border-bottom:1px solid #E3E5EA}td.g{color:#1E8E4E}td.r{color:#C0392B}
.add{margin-top:16px}.add summary{cursor:pointer;font-weight:600;padding:10px 0}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;align-items:end}
@media(max-width:600px){.prod{flex-direction:column}.ph{width:96px}}
</style></head><body>' . $body . '</body></html>';
    if ($exit) exit;
}
