<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'POST only'], 405);
$in = read_json();
if (!empty($in['hp'])) json_out(['ok' => true]);
rate_limit(10, 3600);

$make = clean($in['make'] ?? '', 60); $model = clean($in['model'] ?? '', 60);
$year = clean($in['year'] ?? '', 10); $eng = clean($in['eng'] ?? '', 30);
$phone = norm_phone((string)($in['phone'] ?? ''));
$err = [];
if ($make === '' || $model === '') $err[] = 'Укажите марку и модель';
if (!$phone) $err[] = 'Проверьте номер телефона';
if (empty($in['agree'])) $err[] = 'Нужно согласие на обработку данных';
if ($err) json_out(['ok' => false, 'error' => implode('. ', $err)], 422);

$note = trim("$make $model" . ($year ? ", $year" : '') . ($eng ? ", двигатель $eng" : ''));
$db = db();
$db->prepare('INSERT INTO orders(created,kind,name,phone,dlv,pay,items,total,status,note,ip) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
   ->execute([date('Y-m-d H:i:s'), 'request', '', $phone, '', '', '[]', 0, 'request', $note, client_ip()]);
$id = (int)$db->lastInsertId();
notify("Заявка на подбор №$id", "Авто: $note\nТелефон: $phone\n\nПодберите аккумулятор и напишите покупателю в Max.");
json_out(['ok' => true, 'id' => $id]);
