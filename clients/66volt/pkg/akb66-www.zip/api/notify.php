<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
// Уведомления Т-Банка о статусе платежа. Банк ждёт ответ "OK".

$raw = file_get_contents('php://input') ?: '';
$n = json_decode($raw, true);
if (!is_array($n) || empty($n['Token'])) { http_response_code(400); exit('bad'); }

@file_put_contents(DATA . '/tbank.log', date('c') . ' ' . json_encode(array_diff_key($n, ['Token' => 1, 'Pan' => 1, 'CardId' => 1, 'RebillId' => 1]), JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX);

if (!hash_equals(tbank_token($n), (string)$n['Token'])) { http_response_code(403); exit('bad token'); }
if (($n['TerminalKey'] ?? '') !== cfg('tbank_terminal')) { http_response_code(403); exit('bad terminal'); }

if (preg_match('/^66V-(\d+)$/', (string)($n['OrderId'] ?? ''), $m)) {
    $id = (int)$m[1];
    $db = db();
    $o = $db->query("SELECT * FROM orders WHERE id=$id")->fetch();
    if ($o) {
        $map = ['CONFIRMED' => 'paid', 'AUTHORIZED' => 'paid', 'REJECTED' => 'rejected', 'REFUNDED' => 'refunded', 'PARTIAL_REFUNDED' => 'refunded', 'REVERSED' => 'cancelled'];
        $status = $map[$n['Status'] ?? ''] ?? null;
        $amountOk = (int)($n['Amount'] ?? 0) === (int)$o['total'] * 100;
        if ($status === 'paid' && !$amountOk) $status = null;   // сумма не совпала — не помечаем оплаченным
        if ($status && $status !== $o['status']) {
            $db->prepare('UPDATE orders SET status=?, payment_id=? WHERE id=?')->execute([$status, (string)($n['PaymentId'] ?? $o['payment_id']), $id]);
            $o['status'] = $status;
            notify("Заказ №$id — " . status_name($status), order_text($o));
        }
    }
}
echo 'OK';
