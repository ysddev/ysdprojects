<?php
// Скопируйте этот файл в config.php и заполните. Папка data/ закрыта от доступа из браузера (.htaccess).
return [
    // Куда приходят заказы и заявки
    'shop_email'   => 'akb66volt@mail.ru',
    'from_email'   => 'noreply@akb-66.ru',
    'site_url'     => 'https://akb-66.ru',   // без слэша в конце

    // Т-Банк, интернет-эквайринг. Сначала тестовый терминал (…DEMO), после проверки — рабочий.
    'tbank_terminal' => '',
    'tbank_password' => '',
    'tbank_api'      => 'https://securepay.tinkoff.ru/v2/',
    'tbank_cainfo'   => '',   // путь к PEM с Russian Trusted Root CA, если системных сертификатов хостинга не хватает
    'taxation'       => 'usn_income_outcome', // УСН «доходы минус расходы»
    'vat'            => 'none',               // без НДС

    // Админка: хеш пароля. Сгенерировать: php -r "echo password_hash('ПАРОЛЬ', PASSWORD_DEFAULT);"
    'admin_hash'   => '',

    // Max (необязательно). Токен бота и id чата/пользователя, куда слать уведомления.
    'max_token'    => '',
    'max_chat_id'  => '',
];
